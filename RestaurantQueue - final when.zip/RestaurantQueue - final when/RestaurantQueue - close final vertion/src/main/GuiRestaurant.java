package main;

import Menu.*;
import Stock.*;
import java.awt.Color;
import java.awt.Image;
import javax.swing.*;
import java.io.*;
import java.util.List;
import java.util.Queue;
import javax.swing.table.DefaultTableModel;
import lib.*;

/**
 *
 * @author nanth
 */
public class GuiRestaurant extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GuiRestaurant.class.getName());
    private String namestock[] = {"DrinksStock", "DessertStock", "MaincourseStock"};
    private shopcenter shop;
    private String s;
    private String namefordeletecart;
    private String commentfordeletecart;
    private String namemenu[] = {"Drinks", "Maincourse", "Dessert"};
    private DefaultTableModel DessertPromotion;
    private DefaultTableModel DrinksPromotion;
    private DefaultTableModel MaincoursePromotion;
    private DefaultTableModel Cart;
    private DefaultTableModel Queuetable; 
    String totalprice;

    private final String[] queueColums = { "Queue", "Name", "Price", "Quantity", "Comment", "Summary Price", "Total/Queue" };

    /**
     * Creates new form GuiRestaurant
     */
    public GuiRestaurant() {
        initComponents();
        this.setTitle("Restaurant Queue");
        ImageIcon icon = new ImageIcon("D:\\6721601583\\RestaurantQueue - close final vertion\\RestaurantQueue - close final vertion\\src\\icon\\logo.png");
        Image  image = icon.getImage();
        this.setIconImage(image);
        shop = new shopcenter();
        Drinks Drinks = new Drinks();
        Dessert Dessert = new Dessert();
        Maincourse Maincourse = new Maincourse();

        shop.SetTypetoMenu("Drinks", Drinks);
        shop.SetTypetoMenu("Maincourse", Maincourse);
        shop.SetTypetoMenu("Dessert", Dessert);

        Cart = (DefaultTableModel) CartTable.getModel();
        DessertPromotion = (DefaultTableModel) TableDessert.getModel();
        DrinksPromotion = (DefaultTableModel) TableDrinks.getModel();
        MaincoursePromotion = (DefaultTableModel) TableMaincourse.getModel();
         Queuetable = (DefaultTableModel)QueueTable.getModel(); 
        Managebutton();
        LoadAllMenu();
        LoadAllStock();
        LoadQueueData();
        ClearCart();
        clearTable(CartTable);

        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null);
        setExtendedState(GuiRestaurant.MAXIMIZED_BOTH); //fullscreen every  run

        DessertStock dessertStock = new DessertStock();
        DrinksStock drinksStock = new DrinksStock();
        MaincourseStock maincourseStock = new MaincourseStock();
        shop.SetTypetoStock("Dessert", dessertStock);
        shop.SetTypetoStock("Drinks", drinksStock);
        shop.SetTypetoStock("Maincourse", maincourseStock);

        Totalprice.setText("0.0");
        paymoney.setText("0.0");
        Changeforcustomer.setText("0.0");
        QueueTable.getTableHeader().setReorderingAllowed(false);
        CartTable.getTableHeader().setReorderingAllowed(false);
        TableDessert.getTableHeader().setReorderingAllowed(false);
        TableDrinks.getTableHeader().setReorderingAllowed(false);
        TableMaincourse.getTableHeader().setReorderingAllowed(false);
    }

    private void LoadAllMenu() {
        PageforDrinksMenu.removeAll();
        PageforMaincourseMenu.removeAll();
        PageforDessertMenu.removeAll();
        JTablePromotion();
        for (String filemenu : namemenu) {
            try (
                    FileReader fr = new FileReader(new File(filemenu)); BufferedReader ReadMenu = new BufferedReader(fr);) {
                while ((s = ReadMenu.readLine()) != null) {
                    String text[] = s.split(",");
                    GuiforMenu menu = new GuiforMenu(this);
                    if (text.length > 4) {
                        String name = text[0];
                        String Id = text[1];
                        String price = text[2];
                        String typefood = text[3];
                        String path = text[4]; // ใช้ Index 4

                        menu.setData(Id, name, price, typefood);
                        menu.setPhoto(path);

                        if (typefood.equals("Drinks")) {
                            PageforDrinksMenu.add(menu.getMenuPanel());
                            PageforDrinksMenu.revalidate();
                            PageforDrinksMenu.repaint();
                        }
                        if (text[3].equals("Dessert")) {
                            PageforDessertMenu.add(menu.getMenuPanel());
                            PageforDessertMenu.revalidate();
                            PageforDessertMenu.repaint();
                        }
                        if (text[3].equals("Maincourse")) {
                            PageforMaincourseMenu.add(menu.getMenuPanel());
                            PageforMaincourseMenu.revalidate();
                            PageforMaincourseMenu.repaint();
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private void LoadAllStock() {

        JtableCart();
        PageforDrinksStock.removeAll();
        PageforDessertStock.removeAll();
        PageforMaincourseStock.removeAll();
        GoodsDrinks.removeAll();
        GoodsDessert.removeAll();
        GoodsMaincourse.removeAll();
        for (String filestock : namestock) {
            try (
                    FileReader fr = new FileReader(new File(filestock)); BufferedReader ReadMenu = new BufferedReader(fr);) {
                while ((s = ReadMenu.readLine()) != null) {
                    String text[] = s.split(",");
                    GuiforStock stock = new GuiforStock(this);
                    GuiforGoods goods = new GuiforGoods(this);
                    if (text.length > 4) {
                        String name = text[0];
                        String Id = text[1];
                        String price = text[2];
                        String typefood = text[3];
                        String path = text[4]; // ใช้ Index 4

                        stock.setData(name, price);
                        stock.setPhoto(path);
                        goods.setData(name, price);
                        goods.setPhoto(path);

                        if (typefood.equals("Drinks")) {
                            PageforDrinksStock.add(stock.getStockPanel());
                            PageforDrinksStock.revalidate();
                            PageforDrinksStock.repaint();
                            GoodsDrinks.add(goods.getGoodsPanel());
                            GoodsDrinks.revalidate();
                            GoodsDrinks.repaint();
                        }
                        if (text[3].equals("Dessert")) {
                            PageforDessertStock.add(stock.getStockPanel());
                            PageforDessertStock.revalidate();
                            PageforDessertStock.repaint();
                            GoodsDessert.add(goods.getGoodsPanel());
                            GoodsDessert.revalidate();
                            GoodsDessert.repaint();
                        }
                        if (text[3].equals("Maincourse")) {
                            PageforMaincourseStock.add(stock.getStockPanel());
                            PageforMaincourseStock.revalidate();
                            PageforMaincourseStock.repaint();
                            GoodsMaincourse.add(goods.getGoodsPanel());
                            GoodsMaincourse.revalidate();
                            GoodsMaincourse.repaint();
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // </editor-fold>
    public void AddCart(String name, int quantity, String comment) {
        try {
            shop.Addcart(name, quantity, comment);
            JtableCart();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public void JtableCart() {
        clearTable(CartTable);
        try (
                FileReader read = new FileReader(new File("BillandCart")); BufferedReader reader = new BufferedReader(read);) {
            while ((s = reader.readLine()) != null) {
                String goods[] = new String[5];
                String text[] = s.split(",");

                if (text.length >= 5) {
                    goods[0] = text[0];//name
                    goods[1] = text[1];//price
                    goods[2] = text[2];//quantity
                    goods[3] = text[4];//price*quantity
                    goods[4] = text[3];//comment
                    Cart.addRow(goods);
                }
            }
            calforTotalprice();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void ClearCart() {
        try {
            shop.Clearcart();
            JtableCart();
            paymoney.setText("0,0");
            paymoney.setText("0.0");
            Changeforcustomer.setText("0.0");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void changequantityandcomment(String name, int quantity, String comment) {
        try {
            if (quantity == 0) {
                DeleteCart(name, comment);
            } else {
                shop.Changequantitycart(name, quantity, comment);
                JtableCart();
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void calforTotalprice() {
        try {
            totalprice = Double.toString(shop.Calprice());
            Totalprice.setText(totalprice);

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void JTablePromotion() {
        clearTable(TableDessert);
        clearTable(TableDrinks);
        clearTable(TableMaincourse);
        for (String menu : namemenu) {
            try (
                    FileReader read = new FileReader(new File(menu)); BufferedReader reader = new BufferedReader(read);) {
                while ((s = reader.readLine()) != null) {
                    String text[] = s.split(",");
                    if (text.length > 3) {
                        String[] data = new String[4];
                        data[0] = text[0];//name
                        data[1] = text[1];//id
                        data[2] = text[2];//price
                        data[3] = text[3];//type
                        if (data[3].equals("Dessert")) {
                            DessertPromotion.addRow(data);
                        }
                        if (data[3].equals("Drinks")) {
                            DrinksPromotion.addRow(data);
                        }
                        if (data[3].equals("Maincourse")) {
                            MaincoursePromotion.addRow(data);
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    private void clearTable(JTable Menu) {
        DefaultTableModel table = (DefaultTableModel) Menu.getModel();
        int rowCount = table.getRowCount();

        for (int i = rowCount - 1; i >= 0; i--) {
            table.removeRow(i);
        }
    }

    public void UpdatepPromotion(String typefood, String Id, String name, String Price) {
        Double price = Double.parseDouble(Price);
        try {
            shop.Updatepromotion(typefood, Id, name, price);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void Setchange() {
        String payText = paymoney.getText().trim();
        if (payText.isEmpty() || payText.equals("0.0") || payText.equals("0")) {
            JOptionPane.showMessageDialog(this, "Please enter payment amount",
                    "Invalid payment", JOptionPane.WARNING_MESSAGE);
            Changeforcustomer.setText("");
            return;
        }
        try {
            double allprice = Double.parseDouble(Totalprice.getText());
            double pay = Double.parseDouble(payText);
             double change=0 ;
            if(allprice>0){
             change = pay - allprice;}
            else{Totalprice.setText("Please add goods");
            JOptionPane.showMessageDialog(this, "Doesn't have goods your cart",
                    "Invalid payment",JOptionPane.ERROR_MESSAGE);
            }
            
            
            
            if (change >= 0) {
                String textChange = String.format("%.2f", change);
                Changeforcustomer.setText(textChange);
                
            } else {
                
                Changeforcustomer.setText("Your money not enough");
                
        }} catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "payment amount must be in numbers only.",
                    "Invalid payment", JOptionPane.ERROR_MESSAGE);
            Changeforcustomer.setText("");
        }
    }

    private void Managebutton() {
        SelectTypefood.removeAllItems();
        SelectTypefood.addItem("Drinks");
        SelectTypefood.addItem("Maincourse");
        SelectTypefood.addItem("Dessert");
        SelectTypefood.setSelectedItem(null);
        Totalprice.setEditable(false);
        Changeforcustomer.setEditable(false);
    }

    public void ManagebuttonforAddStock(GuiforMenu ShowguiMenu) throws Exception {
        String price = ShowguiMenu.getTextPrice();
        String typefood = ShowguiMenu.getTextType();
        String Id = ShowguiMenu.getTextId();
        String Name = ShowguiMenu.getTextName();
        try {
            List<String> CheckStock = shop.findstockbyName(Name);
            if (CheckStock.isEmpty()) {
                shop.Addstock(typefood, Id, Name);
                List<String> DatafromMenu = shop.findstockbyName(Name);
                LoadAllStock();
                CheckStock.clear();
            } else {
                throw new InvalidOperationException("This menu " + Name + " ID: " + Id + " is already in stock.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw e;
        }
    }
     
    public void DeleteCart(String name, String comment) throws InvalidOperationException {
        if (name == null || name.isBlank() || comment == null || comment.isBlank()) {
            throw new InvalidOperationException("Must select goods");
        }
        try {
            shop.Deletecart(name, comment);
            JtableCart();
            namefordeletecart = null;
            commentfordeletecart = null;

            paymoney.setText("0,0");
            Changeforcustomer.setText("0.0");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void DeleteMenu(String id) {
        try {
            shop.Deletemenu(id);
            LoadAllMenu();
            LoadAllStock();
            
            JOptionPane.showMessageDialog(this, id + " Has been delete to Menu,",
                    "Delete Menu", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Invalid delete menu",
                    "invalid", JOptionPane.ERROR_MESSAGE);
            System.out.println(e.getMessage());
        }
    }
 
    public void DeleteStock(String name) {
        try {
            shop.Deletestock(name);
            LoadAllStock();
           
            JOptionPane.showMessageDialog(this, name + " Has been delete to Stock.",
                    "Delete Menu Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Cannot Delete stock" + e.getMessage(),
                    "Delete Failed", JOptionPane.ERROR_MESSAGE);
            System.err.println("DeleteStock Errot" + e.getMessage());
        }
    }
    
       public void LoadQueueData() {
           clearTable(QueueTable);
        try (FileReader read=new FileReader("Queue");
                BufferedReader readqueue=new BufferedReader(read);)
        {
           while((s=readqueue.readLine())!=null)
           {    String queue[]=new String[7];
               String text[]=s.split(",");
               if(text.length>6){
               queue[0]=text[0];//queue
               queue[1]=text[1];//name
               queue[2]=text[2];//price
                queue[3]=text[3];//quantity
                queue[4]=text[4];//comment
               queue[5]=text[5];//priceorder
               queue[6]=text[6];//toatl
               Queuetable.addRow(queue);}
           }
                    
        } catch (Exception e) {
            System.out.println("Error loading queue: " + e.getMessage());
        }
    }
    
    private void SaveBillFile() {
        String billPath = "src\\main\\GuiRestaurant\\BillandCart";
        File billFile = new File(billPath);
        // new file if cannot find
        billFile.getParentFile().mkdirs();  
        
        try {
            
            //****BillandCart File****
            FileWriter fw = new FileWriter(billPath, true);
            BufferedWriter bw = new BufferedWriter(fw);
            
            DefaultTableModel model = (DefaultTableModel) CartTable.getModel();
            int rowCount = model.getRowCount();

            if (rowCount == 0) {
                JOptionPane.showMessageDialog(this, "Empty Cart");
                bw.close();
                fw.close();
                return;
            }

            for (int i = 0; i < rowCount; i++) {
                String name = model.getValueAt(i, 0).toString();
                String price = model.getValueAt(i, 1).toString();
                String quantity = model.getValueAt(i, 2).toString();
                String calprice = model.getValueAt(i, 3).toString(); // price * quantity
                String comment = model.getValueAt(i, 4).toString();
                String totalPrice = Totalprice.getText();

                bw.write(name + "," + price + "," + quantity + "," + comment + "," + calprice + "," + totalPrice);
                bw.newLine();
            }
            bw.close();
            fw.close();
            JOptionPane.showMessageDialog(this, "Saved Cart File Successfully!");
        } catch (IOException e) {
            System.out.println("Cannot save file: " + e.getMessage());
        }
    }
    
    public String setBill() {
        DefaultTableModel model = (DefaultTableModel) CartTable.getModel();
        StringBuilder billContent = new StringBuilder();

        // ฟอร์แมต: No(4) Item( - left 20 ) Qty(4 right) Price(10 right, 2 decimals)
        String headerFmt = "%-6s %-21s %5s %10s%n";
        String rowFmt    = "%-6d %-21s %5s %10.2f%n";
        billContent.append(String.format(headerFmt, "No.", "Item", "Qty", "Price"));
        billContent.append("__________________________________________________\n");

        double grandTotal = 0.0;
        int itemCounter = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            itemCounter++;

            // เปลี่ยน index ให้ตรงกับ structure จริงของคุณ
            String name = String.valueOf(model.getValueAt(i, 0));
            String qty  = String.valueOf(model.getValueAt(i, 2));
            String totalStr = String.valueOf(model.getValueAt(i, 3));
            String comment = String.valueOf(model.getValueAt(i, 4));

            double totalPrice = 0.0;
            try {
                totalPrice = Double.parseDouble(totalStr);
            } catch (NumberFormatException e) {
                // ถ้าราคาไม่ถูก ฟอร์แมตเป็น 0.00 หรือแสดงข้อความ error แทนก็ได้
                // ที่นี่เลือกข้ามการเพิ่มยอดรวม แต่แสดงแถวด้วย 0.00
            }
            grandTotal += totalPrice;

            // เพิ่มบรรทัดรายการโดยใช้ฟอร์แมตคงที่
            billContent.append(String.format(rowFmt, itemCounter, truncate(name, 20), qty, totalPrice));

            // ถ้ามี comment ให้ขึ้นเป็นบรรทัดย่อย
            if (comment != null && !comment.trim().isEmpty() && !comment.trim().equalsIgnoreCase("No comment")) {
                billContent.append("    (Note: ").append(comment).append(")\n");
            }
        }
        billContent.append("---------------------------------------------------\n");
        billContent.append(String.format("%-6s %-21s %6s %10.2f%n", "", "", "TOTAL:", grandTotal));
        billContent.append("---------------------------------------------------\n");

        return billContent.toString();
    }
    
    private String truncate(String s, int max) {
        if (s == null) return "";
        if (s.length() <= max) return s;
        return s.substring(0, max - 3) + "...";
    }
        
    public void AddQueueTobill() throws InvalidOperationException
    {
        double pay,change,total;
        
        try {
         pay = Double.parseDouble(paymoney.getText());
        change = Double.parseDouble(Changeforcustomer.getText());
        total = Double.parseDouble(Totalprice.getText());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Invalid money textfield");
        Changeforcustomer.setText("0.0");
        throw new InvalidOperationException("Invalid input for payment or total.");
    }
        
        
        if(CartTable.getRowCount()!=0&&pay>=total&&change>=0)
        {
        
         try {
             shop.Addqueue();
       LoadQueueData(); 
      
            //JOptionPane.showMessageDialog(this, "Saved Queue Successfully!");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Cannot Save Queue" + e.getMessage());
        }
        
       } else if(CartTable.getRowCount()==0)
        { JOptionPane.showMessageDialog(this, "Please select goods");
        throw new InvalidOperationException("Your cart empty");}
        else{
          JOptionPane.showMessageDialog(this, "Please pay money");
           throw new InvalidOperationException("Must pay money");}
       
      
    }

    public void switchPanel(JPanel newPanel) {
        getContentPane().removeAll();
        getContentPane().add(newPanel);
        revalidate();
        repaint();
    }

    public void Deletequeue(int selectedRow)
    {
     
        
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Select queue you want to delete first!");
                return;
            }

            try {
                int queueNumber = Integer.parseInt(QueueTable.getValueAt(selectedRow, 0).toString());
                shop.Deletequeue(queueNumber);
                LoadQueueData(); 
                JOptionPane.showMessageDialog(this, "Delete queue no. " + queueNumber + " successfully!");
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Cannot delete queue. " + e.getMessage());
        }
    }
    public void ClearQueue()
    {
        int confirm = JOptionPane.showConfirmDialog(this, 
                "Are you sure to delete all of queues?", 
                "Confirm to delete queues.", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                shop.Clearqueue();
                LoadQueueData(); 
                
                JOptionPane.showMessageDialog(this, "Deleting queue completed.");
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Cannot delete all of queues: " + e.getMessage());
            }
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jButton1 = new javax.swing.JButton();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        Allpage = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        QueueButton = new java.awt.Button();
        DrinksButton = new java.awt.Button();
        MaincourseButton = new java.awt.Button();
        DessertButton = new java.awt.Button();
        jPanel21 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jPanel84 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        CartButton = new javax.swing.JButton();
        jPanel23 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        ExitGui1 = new javax.swing.JButton();
        jPanel26 = new javax.swing.JPanel();
        label1 = new java.awt.Label();
        jPanel1 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel77 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jPanel80 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jPanel83 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        ManagePage = new javax.swing.JPanel();
        QueuePage = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        NextQueueBTN = new java.awt.Button();
        DeleteQueueBTN = new java.awt.Button();
        ClearQueueBTN = new java.awt.Button();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        QueueTable = new javax.swing.JTable();
        DrinksPage = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        GoodsDrinks = new javax.swing.JPanel();
        MaincoursePage = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        GoodsMaincourse = new javax.swing.JPanel();
        DessertPage = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        GoodsDessert = new javax.swing.JPanel();
        CartPage = new javax.swing.JPanel();
        jPanel29 = new javax.swing.JPanel();
        label2 = new java.awt.Label();
        jPanel63 = new javax.swing.JPanel();
        jPanel79 = new javax.swing.JPanel();
        jPanel78 = new javax.swing.JPanel();
        NextTobill = new javax.swing.JButton();
        jPanel64 = new javax.swing.JPanel();
        jPanel81 = new javax.swing.JPanel();
        jPanel82 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        paymoney = new javax.swing.JTextField();
        Changeforcustomer = new javax.swing.JTextField();
        Totalprice = new javax.swing.JTextField();
        paybutton = new javax.swing.JButton();
        jScrollPane15 = new javax.swing.JScrollPane();
        CartTable = new javax.swing.JTable();
        DeleteCartButton = new javax.swing.JButton();
        ClearCartBTN = new javax.swing.JButton();
        ManageMenuPage = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel150 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jPanel37 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel38 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel39 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        CreateMenubtn = new javax.swing.JButton();
        Drinkmenubtn = new javax.swing.JButton();
        Maincoursemenubtn = new javax.swing.JButton();
        Dessertmenubtn = new javax.swing.JButton();
        Drinkstockbtn = new javax.swing.JButton();
        Maincoursestockbtn = new javax.swing.JButton();
        Dessertstockbtn = new javax.swing.JButton();
        Promotionbtn = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        ManagePageSetting = new javax.swing.JPanel();
        CreateMenu = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel41 = new javax.swing.JPanel();
        jPanel42 = new javax.swing.JPanel();
        jPanel43 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jPanel93 = new javax.swing.JPanel();
        jPanel126 = new javax.swing.JPanel();
        jPanel127 = new javax.swing.JPanel();
        jPanel128 = new javax.swing.JPanel();
        jPanel129 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jPanel87 = new javax.swing.JPanel();
        jPanel44 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jPanel46 = new javax.swing.JPanel();
        jPanel105 = new javax.swing.JPanel();
        TextNamefood = new javax.swing.JTextField();
        jPanel88 = new javax.swing.JPanel();
        jPanel89 = new javax.swing.JPanel();
        jPanel130 = new javax.swing.JPanel();
        jPanel131 = new javax.swing.JPanel();
        jPanel132 = new javax.swing.JPanel();
        jPanel133 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel90 = new javax.swing.JPanel();
        jPanel106 = new javax.swing.JPanel();
        jPanel107 = new javax.swing.JPanel();
        jPanel108 = new javax.swing.JPanel();
        jPanel109 = new javax.swing.JPanel();
        SelectTypefood = new javax.swing.JComboBox<>();
        jPanel91 = new javax.swing.JPanel();
        jPanel92 = new javax.swing.JPanel();
        jPanel134 = new javax.swing.JPanel();
        jPanel135 = new javax.swing.JPanel();
        jPanel136 = new javax.swing.JPanel();
        jPanel137 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jPanel94 = new javax.swing.JPanel();
        jPanel110 = new javax.swing.JPanel();
        jPanel111 = new javax.swing.JPanel();
        jPanel112 = new javax.swing.JPanel();
        jPanel113 = new javax.swing.JPanel();
        TextID = new javax.swing.JTextField();
        jPanel95 = new javax.swing.JPanel();
        jPanel96 = new javax.swing.JPanel();
        jPanel138 = new javax.swing.JPanel();
        jPanel139 = new javax.swing.JPanel();
        jPanel140 = new javax.swing.JPanel();
        jPanel141 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jPanel97 = new javax.swing.JPanel();
        jPanel114 = new javax.swing.JPanel();
        jPanel115 = new javax.swing.JPanel();
        jPanel116 = new javax.swing.JPanel();
        jPanel117 = new javax.swing.JPanel();
        TextPrice = new javax.swing.JTextField();
        jPanel98 = new javax.swing.JPanel();
        jPanel99 = new javax.swing.JPanel();
        jPanel142 = new javax.swing.JPanel();
        jPanel143 = new javax.swing.JPanel();
        jPanel144 = new javax.swing.JPanel();
        jPanel145 = new javax.swing.JPanel();
        jLabel37 = new javax.swing.JLabel();
        jPanel100 = new javax.swing.JPanel();
        jPanel118 = new javax.swing.JPanel();
        jPanel119 = new javax.swing.JPanel();
        jPanel120 = new javax.swing.JPanel();
        jPanel121 = new javax.swing.JPanel();
        Textnamephoto = new javax.swing.JTextField();
        jPanel101 = new javax.swing.JPanel();
        jPanel146 = new javax.swing.JPanel();
        jPanel147 = new javax.swing.JPanel();
        jPanel148 = new javax.swing.JPanel();
        jPanel149 = new javax.swing.JPanel();
        Addphotobutton = new javax.swing.JButton();
        jPanel102 = new javax.swing.JPanel();
        jPanel103 = new javax.swing.JPanel();
        jPanel122 = new javax.swing.JPanel();
        jPanel123 = new javax.swing.JPanel();
        jPanel124 = new javax.swing.JPanel();
        jPanel125 = new javax.swing.JPanel();
        AddMenuButton = new javax.swing.JButton();
        jPanel104 = new javax.swing.JPanel();
        DrinksMenu = new javax.swing.JPanel();
        jPanel47 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        DRMscroll = new javax.swing.JScrollPane();
        PageforDrinksMenu = new javax.swing.JPanel();
        MaincourseMenu = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel49 = new javax.swing.JPanel();
        MCMscroll = new javax.swing.JScrollPane();
        PageforMaincourseMenu = new javax.swing.JPanel();
        DessertMenu = new javax.swing.JPanel();
        jPanel50 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jPanel51 = new javax.swing.JPanel();
        DSMscroll = new javax.swing.JScrollPane();
        PageforDessertMenu = new javax.swing.JPanel();
        DrinksStock = new javax.swing.JPanel();
        jPanel52 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jPanel53 = new javax.swing.JPanel();
        DRTscroll = new javax.swing.JScrollPane();
        PageforDrinksStock = new javax.swing.JPanel();
        MaincourseStock = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel55 = new javax.swing.JPanel();
        MCTscroll = new javax.swing.JScrollPane();
        PageforMaincourseStock = new javax.swing.JPanel();
        DessertStock = new javax.swing.JPanel();
        jPanel56 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        DSTscroll = new javax.swing.JScrollPane();
        PageforDessertStock = new javax.swing.JPanel();
        DeletePanel = new javax.swing.JPanel();
        jPanel85 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jPanel86 = new javax.swing.JPanel();
        jScrollPane16 = new javax.swing.JScrollPane();
        PageforDelete = new javax.swing.JPanel();
        ManagePromotion = new javax.swing.JPanel();
        jPanel58 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jPanel59 = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        ManagePromotionPage = new javax.swing.JPanel();
        PromotionDrinks = new javax.swing.JPanel();
        jPanel65 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jPanel66 = new javax.swing.JPanel();
        jPanel68 = new javax.swing.JPanel();
        jPanel69 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane12 = new javax.swing.JScrollPane();
        TableDrinks = new javax.swing.JTable();
        DrinksUpdate = new javax.swing.JButton();
        PromotionMaincourse = new javax.swing.JPanel();
        jPanel67 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jPanel70 = new javax.swing.JPanel();
        jPanel71 = new javax.swing.JPanel();
        jPanel72 = new javax.swing.JPanel();
        jPanel61 = new javax.swing.JPanel();
        jScrollPane13 = new javax.swing.JScrollPane();
        TableMaincourse = new javax.swing.JTable();
        MaincourseUpdate = new javax.swing.JButton();
        PromotionDessert = new javax.swing.JPanel();
        jPanel73 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jPanel74 = new javax.swing.JPanel();
        jPanel75 = new javax.swing.JPanel();
        jPanel76 = new javax.swing.JPanel();
        jPanel62 = new javax.swing.JPanel();
        jScrollPane14 = new javax.swing.JScrollPane();
        TableDessert = new javax.swing.JTable();
        DessertUpdate = new javax.swing.JButton();

        jButton1.setText("jButton1");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel4.setText("Drinks");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));

        Allpage.setPreferredSize(new java.awt.Dimension(827, 164));
        Allpage.setLayout(new java.awt.CardLayout());

        jPanel30.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(219, 199, 231));
        jPanel2.setAlignmentY(0.0F);
        jPanel2.setPreferredSize(new java.awt.Dimension(400, 160));
        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel6.setBackground(new java.awt.Color(219, 199, 231));
        jPanel6.setAlignmentX(0.0F);
        jPanel6.setAlignmentY(0.0F);
        jPanel6.setMinimumSize(new java.awt.Dimension(375, 30));
        jPanel6.setPreferredSize(new java.awt.Dimension(100, 40));
        java.awt.GridBagLayout jPanel6Layout = new java.awt.GridBagLayout();
        jPanel6Layout.rowHeights = new int[] {50};
        jPanel6.setLayout(jPanel6Layout);

        QueueButton.setBackground(new java.awt.Color(253, 212, 212));
        QueueButton.setFont(new java.awt.Font("Tw Cen MT", 1, 20)); // NOI18N
        QueueButton.setForeground(new java.awt.Color(146, 22, 22));
        QueueButton.setLabel("Queue");
        QueueButton.setName(""); // NOI18N
        QueueButton.setPreferredSize(new java.awt.Dimension(50, 25));
        QueueButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                QueueButtonMouseClicked(evt);
            }
        });
        QueueButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QueueButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 80;
        gridBagConstraints.ipady = 20;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 90, 30, 0);
        jPanel6.add(QueueButton, gridBagConstraints);

        DrinksButton.setBackground(new java.awt.Color(253, 212, 212));
        DrinksButton.setFont(new java.awt.Font("Tw Cen MT", 1, 20)); // NOI18N
        DrinksButton.setForeground(new java.awt.Color(146, 22, 22));
        DrinksButton.setLabel("Drinks");
        DrinksButton.setPreferredSize(new java.awt.Dimension(50, 25));
        DrinksButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DrinksButtonMouseClicked(evt);
            }
        });
        DrinksButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DrinksButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 80;
        gridBagConstraints.ipady = 20;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 100, 30, 20);
        jPanel6.add(DrinksButton, gridBagConstraints);

        MaincourseButton.setBackground(new java.awt.Color(253, 212, 212));
        MaincourseButton.setFont(new java.awt.Font("Tw Cen MT", 1, 20)); // NOI18N
        MaincourseButton.setForeground(new java.awt.Color(146, 22, 22));
        MaincourseButton.setLabel("Maincourse");
        MaincourseButton.setPreferredSize(new java.awt.Dimension(50, 25));
        MaincourseButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MaincourseButtonMouseClicked(evt);
            }
        });
        MaincourseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MaincourseButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 80;
        gridBagConstraints.ipady = 20;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 60, 30, 70);
        jPanel6.add(MaincourseButton, gridBagConstraints);

        DessertButton.setBackground(new java.awt.Color(253, 212, 212));
        DessertButton.setFont(new java.awt.Font("Tw Cen MT", 1, 20)); // NOI18N
        DessertButton.setForeground(new java.awt.Color(146, 22, 22));
        DessertButton.setLabel("Dessert");
        DessertButton.setPreferredSize(new java.awt.Dimension(50, 35));
        DessertButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DessertButtonMouseClicked(evt);
            }
        });
        DessertButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DessertButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.RELATIVE;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 80;
        gridBagConstraints.ipady = 20;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 30, 95);
        jPanel6.add(DessertButton, gridBagConstraints);

        jPanel2.add(jPanel6, java.awt.BorderLayout.CENTER);

        jPanel21.setBackground(new java.awt.Color(219, 199, 231));
        jPanel21.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel21.setLayout(new java.awt.BorderLayout());

        jLabel34.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/PicAddcart_1.jpg"))); // NOI18N
        jPanel21.add(jLabel34, java.awt.BorderLayout.CENTER);

        jPanel84.setPreferredSize(new java.awt.Dimension(500, 30));
        jPanel84.setLayout(new java.awt.BorderLayout());

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/PicAddcart_1.jpg"))); // NOI18N
        jPanel84.add(jLabel38, java.awt.BorderLayout.CENTER);

        jPanel21.add(jPanel84, java.awt.BorderLayout.LINE_END);

        jPanel2.add(jPanel21, java.awt.BorderLayout.PAGE_END);

        jPanel18.setPreferredSize(new java.awt.Dimension(100, 80));
        jPanel18.setLayout(new java.awt.BorderLayout());

        jPanel22.setBackground(new java.awt.Color(219, 199, 231));
        jPanel22.setPreferredSize(new java.awt.Dimension(70, 40));

        CartButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-cart.gif"))); // NOI18N
        CartButton.setBorderPainted(false);
        CartButton.setContentAreaFilled(false);
        CartButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CartButtonMouseClicked(evt);
            }
        });
        CartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                .addComponent(CartButton, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addComponent(CartButton, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel18.add(jPanel22, java.awt.BorderLayout.LINE_END);

        jPanel23.setBackground(new java.awt.Color(219, 199, 231));
        jPanel23.setForeground(new java.awt.Color(255, 255, 204));
        jPanel23.setPreferredSize(new java.awt.Dimension(140, 40));
        jPanel23.setLayout(null);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-restaurant-40.png"))); // NOI18N
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel23.add(jButton3);
        jButton3.setBounds(10, 10, 46, 47);

        ExitGui1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-close-sign-40.png"))); // NOI18N
        ExitGui1.setAlignmentY(0.0F);
        ExitGui1.setBorderPainted(false);
        ExitGui1.setContentAreaFilled(false);
        ExitGui1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitGui1ActionPerformed(evt);
            }
        });
        jPanel23.add(ExitGui1);
        ExitGui1.setBounds(60, 10, 46, 47);

        jPanel18.add(jPanel23, java.awt.BorderLayout.LINE_START);

        jPanel26.setBackground(new java.awt.Color(219, 199, 231));

        label1.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        label1.setForeground(new java.awt.Color(146, 22, 22));
        label1.setText("Restaurant Queue      ");
        jPanel26.add(label1);

        jPanel18.add(jPanel26, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel18, java.awt.BorderLayout.PAGE_START);

        jPanel30.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jPanel1.setBackground(new java.awt.Color(219, 199, 231));
        jPanel1.setPreferredSize(new java.awt.Dimension(40, 100));
        jPanel1.setLayout(new java.awt.BorderLayout());

        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/PicAddcart_1.jpg"))); // NOI18N
        jPanel1.add(jLabel32, java.awt.BorderLayout.CENTER);

        jPanel30.add(jPanel1, java.awt.BorderLayout.LINE_START);

        jPanel3.setBackground(new java.awt.Color(219, 199, 231));
        jPanel3.setForeground(new java.awt.Color(255, 255, 204));
        jPanel3.setPreferredSize(new java.awt.Dimension(40, 100));
        jPanel3.setLayout(new java.awt.BorderLayout());

        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/PicAddcart_1.jpg"))); // NOI18N
        jPanel3.add(jLabel33, java.awt.BorderLayout.CENTER);

        jPanel30.add(jPanel3, java.awt.BorderLayout.LINE_END);

        jPanel4.setBackground(new java.awt.Color(219, 199, 231));
        jPanel4.setPreferredSize(new java.awt.Dimension(100, 60));
        jPanel4.setLayout(new java.awt.BorderLayout());

        jPanel77.setPreferredSize(new java.awt.Dimension(700, 60));
        jPanel77.setLayout(new java.awt.BorderLayout());

        jLabel36.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/PicAddcart_1.jpg"))); // NOI18N
        jPanel77.add(jLabel36, java.awt.BorderLayout.CENTER);

        jPanel4.add(jPanel77, java.awt.BorderLayout.LINE_START);

        jPanel80.setPreferredSize(new java.awt.Dimension(700, 60));
        jPanel80.setLayout(new java.awt.BorderLayout());

        jLabel31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/PicAddcart_1.jpg"))); // NOI18N
        jPanel80.add(jLabel31, java.awt.BorderLayout.CENTER);

        jPanel4.add(jPanel80, java.awt.BorderLayout.LINE_END);

        jPanel83.setLayout(new java.awt.BorderLayout());

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/PicAddcart_1.jpg"))); // NOI18N
        jPanel83.add(jLabel35, java.awt.BorderLayout.CENTER);

        jPanel4.add(jPanel83, java.awt.BorderLayout.CENTER);

        jPanel30.add(jPanel4, java.awt.BorderLayout.PAGE_END);

        ManagePage.setLayout(new java.awt.CardLayout());

        QueuePage.setLayout(new java.awt.BorderLayout());

        jPanel11.setBackground(new java.awt.Color(253, 212, 212));
        jPanel11.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel11.setLayout(new java.awt.GridBagLayout());

        NextQueueBTN.setBackground(new java.awt.Color(219, 199, 231));
        NextQueueBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        NextQueueBTN.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        NextQueueBTN.setForeground(new java.awt.Color(146, 22, 22));
        NextQueueBTN.setLabel("Next Queue");
        NextQueueBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextQueueBTNActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 1;
        gridBagConstraints.ipady = 10;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(0, 200, 0, 130);
        jPanel11.add(NextQueueBTN, gridBagConstraints);

        DeleteQueueBTN.setBackground(new java.awt.Color(219, 199, 231));
        DeleteQueueBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        DeleteQueueBTN.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        DeleteQueueBTN.setForeground(new java.awt.Color(146, 22, 22));
        DeleteQueueBTN.setLabel("Delete");
        DeleteQueueBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteQueueBTNActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 1;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 130);
        jPanel11.add(DeleteQueueBTN, gridBagConstraints);

        ClearQueueBTN.setBackground(new java.awt.Color(219, 199, 231));
        ClearQueueBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        ClearQueueBTN.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        ClearQueueBTN.setForeground(new java.awt.Color(146, 22, 22));
        ClearQueueBTN.setLabel("Clear");
        ClearQueueBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearQueueBTNActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 1;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 200);
        jPanel11.add(ClearQueueBTN, gridBagConstraints);

        QueuePage.add(jPanel11, java.awt.BorderLayout.PAGE_END);

        jPanel12.setBackground(new java.awt.Color(253, 212, 212));
        jPanel12.setPreferredSize(new java.awt.Dimension(30, 100));
        QueuePage.add(jPanel12, java.awt.BorderLayout.LINE_START);

        jPanel13.setBackground(new java.awt.Color(253, 212, 212));
        jPanel13.setPreferredSize(new java.awt.Dimension(30, 100));
        QueuePage.add(jPanel13, java.awt.BorderLayout.LINE_END);

        jPanel14.setBackground(new java.awt.Color(253, 212, 212));
        jPanel14.setPreferredSize(new java.awt.Dimension(100, 70));
        jPanel14.setLayout(new java.awt.BorderLayout());

        jLabel40.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(175, 45, 45));
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("Queue");
        jPanel14.add(jLabel40, java.awt.BorderLayout.CENTER);

        QueuePage.add(jPanel14, java.awt.BorderLayout.PAGE_START);

        jScrollPane1.setBackground(new java.awt.Color(219, 199, 231));

        QueueTable.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        QueueTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Queue", "OrderList", "Price", "Quantity", "Comment", "Summary Price", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        QueueTable.setPreferredSize(new java.awt.Dimension(300, 800));
        jScrollPane1.setViewportView(QueueTable);
        if (QueueTable.getColumnModel().getColumnCount() > 0) {
            QueueTable.getColumnModel().getColumn(0).setResizable(false);
            QueueTable.getColumnModel().getColumn(1).setResizable(false);
            QueueTable.getColumnModel().getColumn(2).setResizable(false);
            QueueTable.getColumnModel().getColumn(3).setResizable(false);
            QueueTable.getColumnModel().getColumn(4).setResizable(false);
            QueueTable.getColumnModel().getColumn(5).setResizable(false);
            QueueTable.getColumnModel().getColumn(6).setResizable(false);
        }

        QueuePage.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        ManagePage.add(QueuePage, "card2");

        DrinksPage.setBackground(new java.awt.Color(255, 255, 255));
        DrinksPage.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(255, 204, 204));

        jLabel5.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(175, 45, 45));
        jLabel5.setText("Drinks");
        jPanel5.add(jLabel5);

        DrinksPage.add(jPanel5, java.awt.BorderLayout.PAGE_START);

        jScrollPane3.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setPreferredSize(new java.awt.Dimension(1380, 500));

        GoodsDrinks.setBackground(new java.awt.Color(249, 235, 235));
        GoodsDrinks.setPreferredSize(new java.awt.Dimension(1380, 2000));
        GoodsDrinks.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        jScrollPane3.setViewportView(GoodsDrinks);

        DrinksPage.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        ManagePage.add(DrinksPage, "card3");

        MaincoursePage.setBackground(new java.awt.Color(249, 235, 235));
        MaincoursePage.setLayout(new java.awt.BorderLayout());

        jPanel9.setBackground(new java.awt.Color(255, 204, 204));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(175, 45, 45));
        jLabel6.setText("Maincourse");
        jPanel9.add(jLabel6);

        MaincoursePage.add(jPanel9, java.awt.BorderLayout.PAGE_START);

        jScrollPane4.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane4.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane4.setPreferredSize(new java.awt.Dimension(1380, 500));

        GoodsMaincourse.setBackground(new java.awt.Color(249, 235, 235));
        GoodsMaincourse.setPreferredSize(new java.awt.Dimension(1380, 2000));
        GoodsMaincourse.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        jScrollPane4.setViewportView(GoodsMaincourse);

        MaincoursePage.add(jScrollPane4, java.awt.BorderLayout.CENTER);

        ManagePage.add(MaincoursePage, "card4");

        DessertPage.setBackground(new java.awt.Color(249, 235, 235));
        DessertPage.setForeground(new java.awt.Color(175, 45, 45));
        DessertPage.setLayout(new java.awt.BorderLayout());

        jPanel28.setBackground(new java.awt.Color(255, 204, 204));

        jLabel7.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(175, 45, 45));
        jLabel7.setText("Dessert");
        jPanel28.add(jLabel7);

        DessertPage.add(jPanel28, java.awt.BorderLayout.PAGE_START);

        jScrollPane5.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane5.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane5.setPreferredSize(new java.awt.Dimension(1380, 500));

        GoodsDessert.setBackground(new java.awt.Color(249, 235, 235));
        GoodsDessert.setPreferredSize(new java.awt.Dimension(1380, 2000));
        GoodsDessert.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        jScrollPane5.setViewportView(GoodsDessert);

        DessertPage.add(jScrollPane5, java.awt.BorderLayout.CENTER);

        ManagePage.add(DessertPage, "card5");

        CartPage.setBackground(new java.awt.Color(255, 255, 255));
        CartPage.setPreferredSize(new java.awt.Dimension(200, 300));
        CartPage.setLayout(new java.awt.BorderLayout());

        jPanel29.setBackground(new java.awt.Color(255, 204, 204));
        jPanel29.setLayout(new java.awt.BorderLayout());

        label2.setAlignment(java.awt.Label.CENTER);
        label2.setBackground(new java.awt.Color(255, 204, 204));
        label2.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        label2.setForeground(new java.awt.Color(175, 45, 45));
        label2.setText("Cart");
        jPanel29.add(label2, java.awt.BorderLayout.CENTER);

        CartPage.add(jPanel29, java.awt.BorderLayout.PAGE_START);

        jPanel63.setBackground(new java.awt.Color(249, 235, 235));
        jPanel63.setPreferredSize(new java.awt.Dimension(50, 385));

        javax.swing.GroupLayout jPanel63Layout = new javax.swing.GroupLayout(jPanel63);
        jPanel63.setLayout(jPanel63Layout);
        jPanel63Layout.setHorizontalGroup(
            jPanel63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );
        jPanel63Layout.setVerticalGroup(
            jPanel63Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 456, Short.MAX_VALUE)
        );

        CartPage.add(jPanel63, java.awt.BorderLayout.LINE_END);

        jPanel79.setBackground(new java.awt.Color(249, 235, 235));
        jPanel79.setPreferredSize(new java.awt.Dimension(50, 335));

        javax.swing.GroupLayout jPanel79Layout = new javax.swing.GroupLayout(jPanel79);
        jPanel79.setLayout(jPanel79Layout);
        jPanel79Layout.setHorizontalGroup(
            jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 50, Short.MAX_VALUE)
        );
        jPanel79Layout.setVerticalGroup(
            jPanel79Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 456, Short.MAX_VALUE)
        );

        CartPage.add(jPanel79, java.awt.BorderLayout.LINE_START);

        jPanel78.setBackground(new java.awt.Color(249, 235, 235));
        jPanel78.setPreferredSize(new java.awt.Dimension(1506, 50));

        NextTobill.setBackground(new java.awt.Color(219, 199, 231));
        NextTobill.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        NextTobill.setForeground(new java.awt.Color(175, 45, 45));
        NextTobill.setText("Next");
        NextTobill.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NextTobillActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel78Layout = new javax.swing.GroupLayout(jPanel78);
        jPanel78.setLayout(jPanel78Layout);
        jPanel78Layout.setHorizontalGroup(
            jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel78Layout.createSequentialGroup()
                .addContainerGap(1204, Short.MAX_VALUE)
                .addComponent(NextTobill, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60))
        );
        jPanel78Layout.setVerticalGroup(
            jPanel78Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel78Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(NextTobill)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        CartPage.add(jPanel78, java.awt.BorderLayout.PAGE_END);

        jPanel64.setLayout(new javax.swing.BoxLayout(jPanel64, javax.swing.BoxLayout.LINE_AXIS));

        jPanel81.setBackground(new java.awt.Color(249, 235, 235));

        jPanel82.setBackground(new java.awt.Color(249, 235, 235));

        jLabel27.setFont(new java.awt.Font("Times New Roman", 1, 30)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(146, 22, 22));
        jLabel27.setText("Cashier");

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel28.setText("Money :");

        jLabel29.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel29.setText("Change :");

        jLabel30.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel30.setText("Total Price :");

        paymoney.setPreferredSize(new java.awt.Dimension(70, 30));
        paymoney.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                paymoneyMouseClicked(evt);
            }
        });
        paymoney.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paymoneyActionPerformed(evt);
            }
        });

        Changeforcustomer.setPreferredSize(new java.awt.Dimension(70, 30));

        Totalprice.setPreferredSize(new java.awt.Dimension(70, 30));

        paybutton.setBackground(new java.awt.Color(176, 199, 249));
        paybutton.setFont(new java.awt.Font("Tw Cen MT", 1, 20)); // NOI18N
        paybutton.setForeground(new java.awt.Color(255, 255, 255));
        paybutton.setText("Pay");
        paybutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paybuttonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel82Layout = new javax.swing.GroupLayout(jPanel82);
        jPanel82.setLayout(jPanel82Layout);
        jPanel82Layout.setHorizontalGroup(
            jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel82Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel29)
                    .addComponent(jLabel28)
                    .addComponent(jLabel30))
                .addGap(21, 21, 21)
                .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel82Layout.createSequentialGroup()
                        .addComponent(paymoney, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(paybutton))
                    .addGroup(jPanel82Layout.createSequentialGroup()
                        .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Changeforcustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Totalprice, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 84, Short.MAX_VALUE)))
                .addGap(94, 94, 94))
            .addGroup(jPanel82Layout.createSequentialGroup()
                .addGap(226, 226, 226)
                .addComponent(jLabel27)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel82Layout.setVerticalGroup(
            jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel82Layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jLabel27)
                .addGap(38, 38, 38)
                .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Totalprice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30))
                .addGap(18, 18, 18)
                .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(paymoney, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel28)
                    .addComponent(paybutton))
                .addGap(18, 18, 18)
                .addGroup(jPanel82Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel29)
                    .addComponent(Changeforcustomer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane15.setPreferredSize(new java.awt.Dimension(200, 402));

        CartTable.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        CartTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Name", "Price", "Quantity", "Calprice", "Comment"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        CartTable.setPreferredSize(new java.awt.Dimension(400, 800));
        CartTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CartTableMouseClicked(evt);
            }
        });
        jScrollPane15.setViewportView(CartTable);
        if (CartTable.getColumnModel().getColumnCount() > 0) {
            CartTable.getColumnModel().getColumn(0).setResizable(false);
            CartTable.getColumnModel().getColumn(1).setResizable(false);
            CartTable.getColumnModel().getColumn(2).setResizable(false);
            CartTable.getColumnModel().getColumn(3).setResizable(false);
            CartTable.getColumnModel().getColumn(4).setResizable(false);
        }

        DeleteCartButton.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        DeleteCartButton.setForeground(new java.awt.Color(146, 22, 22));
        DeleteCartButton.setText("Delete");
        DeleteCartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteCartButtonActionPerformed(evt);
            }
        });

        ClearCartBTN.setBackground(new java.awt.Color(255, 248, 248));
        ClearCartBTN.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N
        ClearCartBTN.setForeground(new java.awt.Color(255, 51, 51));
        ClearCartBTN.setText("Clear");
        ClearCartBTN.setContentAreaFilled(false);
        ClearCartBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearCartBTNActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel81Layout = new javax.swing.GroupLayout(jPanel81);
        jPanel81.setLayout(jPanel81Layout);
        jPanel81Layout.setHorizontalGroup(
            jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel81Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel82, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane15, javax.swing.GroupLayout.DEFAULT_SIZE, 666, Short.MAX_VALUE)
                    .addGroup(jPanel81Layout.createSequentialGroup()
                        .addComponent(ClearCartBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(DeleteCartButton, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel81Layout.setVerticalGroup(
            jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel81Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel82, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel81Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ClearCartBTN, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(DeleteCartButton, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel64.add(jPanel81);

        CartPage.add(jPanel64, java.awt.BorderLayout.CENTER);

        ManagePage.add(CartPage, "card6");

        jPanel30.add(ManagePage, java.awt.BorderLayout.CENTER);

        Allpage.add(jPanel30, "card2");

        ManageMenuPage.setLayout(new java.awt.BorderLayout());

        jPanel32.setBackground(new java.awt.Color(255, 255, 255));
        jPanel32.setPreferredSize(new java.awt.Dimension(569, 70));
        jPanel32.setLayout(new java.awt.BorderLayout());

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-arrow-40.png"))); // NOI18N
        jButton4.setBorderPainted(false);
        jButton4.setContentAreaFilled(false);
        jButton4.setPreferredSize(new java.awt.Dimension(100, 47));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel32.add(jButton4, java.awt.BorderLayout.LINE_START);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/BackgroundforSettingPage.png"))); // NOI18N
        jLabel1.setPreferredSize(new java.awt.Dimension(600, 417));
        jPanel32.add(jLabel1, java.awt.BorderLayout.LINE_START);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/BackgroundforSettingPage.png"))); // NOI18N
        jPanel32.add(jLabel18, java.awt.BorderLayout.LINE_END);

        jPanel150.setLayout(new java.awt.BorderLayout());

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/BackgroundforSettingPage.png"))); // NOI18N
        jPanel150.add(jLabel9, java.awt.BorderLayout.CENTER);

        jPanel32.add(jPanel150, java.awt.BorderLayout.CENTER);

        ManageMenuPage.add(jPanel32, java.awt.BorderLayout.PAGE_START);

        jPanel33.setBackground(new java.awt.Color(255, 255, 255));
        jPanel33.setPreferredSize(new java.awt.Dimension(400, 367));
        jPanel33.setLayout(new java.awt.BorderLayout());

        jPanel34.setBackground(new java.awt.Color(255, 255, 255));
        jPanel34.setPreferredSize(new java.awt.Dimension(300, 371));
        jPanel34.setLayout(new java.awt.BorderLayout());

        jPanel35.setBackground(new java.awt.Color(255, 153, 153));
        jPanel35.setPreferredSize(new java.awt.Dimension(5, 435));

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3628, Short.MAX_VALUE)
        );

        jPanel34.add(jPanel35, java.awt.BorderLayout.LINE_END);

        jPanel36.setBackground(new java.awt.Color(255, 255, 255));
        jPanel36.setForeground(new java.awt.Color(255, 204, 255));

        jPanel37.setBackground(new java.awt.Color(255, 153, 153));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Manage Menu");

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addComponent(jLabel2))
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jLabel2))
        );

        jPanel38.setBackground(new java.awt.Color(255, 153, 153));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Manage Promotion");

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jLabel3))
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jLabel3))
        );

        jPanel39.setBackground(new java.awt.Color(255, 153, 153));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Manage Stock");

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel8))
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jLabel8))
        );

        CreateMenubtn.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        CreateMenubtn.setText("Create Menu");
        CreateMenubtn.setContentAreaFilled(false);
        CreateMenubtn.setOpaque(true);
        CreateMenubtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CreateMenubtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                CreateMenubtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                CreateMenubtnMouseExited(evt);
            }
        });
        CreateMenubtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreateMenubtnActionPerformed(evt);
            }
        });

        Drinkmenubtn.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Drinkmenubtn.setText("Drinks");
        Drinkmenubtn.setContentAreaFilled(false);
        Drinkmenubtn.setOpaque(true);
        Drinkmenubtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DrinkmenubtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                DrinkmenubtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                DrinkmenubtnMouseExited(evt);
            }
        });
        Drinkmenubtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DrinkmenubtnActionPerformed(evt);
            }
        });

        Maincoursemenubtn.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Maincoursemenubtn.setText("Maincourse");
        Maincoursemenubtn.setContentAreaFilled(false);
        Maincoursemenubtn.setOpaque(true);
        Maincoursemenubtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MaincoursemenubtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                MaincoursemenubtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                MaincoursemenubtnMouseExited(evt);
            }
        });
        Maincoursemenubtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MaincoursemenubtnActionPerformed(evt);
            }
        });

        Dessertmenubtn.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Dessertmenubtn.setText("Dessert");
        Dessertmenubtn.setContentAreaFilled(false);
        Dessertmenubtn.setOpaque(true);
        Dessertmenubtn.setPreferredSize(new java.awt.Dimension(95, 24));
        Dessertmenubtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DessertmenubtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                DessertmenubtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                DessertmenubtnMouseExited(evt);
            }
        });
        Dessertmenubtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DessertmenubtnActionPerformed(evt);
            }
        });

        Drinkstockbtn.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Drinkstockbtn.setText("Drinks ");
        Drinkstockbtn.setContentAreaFilled(false);
        Drinkstockbtn.setOpaque(true);
        Drinkstockbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DrinkstockbtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                DrinkstockbtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                DrinkstockbtnMouseExited(evt);
            }
        });
        Drinkstockbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DrinkstockbtnActionPerformed(evt);
            }
        });

        Maincoursestockbtn.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Maincoursestockbtn.setText("Maincourse");
        Maincoursestockbtn.setContentAreaFilled(false);
        Maincoursestockbtn.setOpaque(true);
        Maincoursestockbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MaincoursestockbtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                MaincoursestockbtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                MaincoursestockbtnMouseExited(evt);
            }
        });
        Maincoursestockbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MaincoursestockbtnActionPerformed(evt);
            }
        });

        Dessertstockbtn.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Dessertstockbtn.setText("Dessert");
        Dessertstockbtn.setContentAreaFilled(false);
        Dessertstockbtn.setOpaque(true);
        Dessertstockbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DessertstockbtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                DessertstockbtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                DessertstockbtnMouseExited(evt);
            }
        });
        Dessertstockbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DessertstockbtnActionPerformed(evt);
            }
        });

        Promotionbtn.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        Promotionbtn.setText("Promotion");
        Promotionbtn.setContentAreaFilled(false);
        Promotionbtn.setOpaque(true);
        Promotionbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PromotionbtnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                PromotionbtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                PromotionbtnMouseExited(evt);
            }
        });
        Promotionbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PromotionbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(CreateMenubtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Drinkmenubtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Maincoursemenubtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Dessertmenubtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Drinkstockbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Dessertstockbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Maincoursestockbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel38, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(Promotionbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CreateMenubtn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Drinkmenubtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Maincoursemenubtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Dessertmenubtn, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Drinkstockbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Maincoursestockbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Dessertstockbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(Promotionbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(3162, Short.MAX_VALUE))
        );

        jPanel34.add(jPanel36, java.awt.BorderLayout.CENTER);

        jPanel33.add(jPanel34, java.awt.BorderLayout.LINE_END);

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/823486a158b1b4c54fa97524664f68aa.jpg"))); // NOI18N
        jPanel33.add(jLabel19, java.awt.BorderLayout.LINE_START);

        ManageMenuPage.add(jPanel33, java.awt.BorderLayout.LINE_START);

        ManagePageSetting.setLayout(new java.awt.CardLayout());

        CreateMenu.setPreferredSize(new java.awt.Dimension(500, 300));
        CreateMenu.setLayout(new java.awt.BorderLayout());

        jPanel40.setBackground(new java.awt.Color(255, 153, 153));
        jPanel40.setPreferredSize(new java.awt.Dimension(473, 60));

        jLabel10.setFont(new java.awt.Font("Tw Cen MT", 1, 30)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Create Menu");
        jLabel10.setToolTipText("");

        javax.swing.GroupLayout jPanel40Layout = new javax.swing.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel40Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 2990, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel40Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 48, Short.MAX_VALUE)
                .addContainerGap())
        );

        CreateMenu.add(jPanel40, java.awt.BorderLayout.PAGE_START);

        jPanel41.setBackground(new java.awt.Color(255, 153, 153));
        jPanel41.setForeground(new java.awt.Color(255, 204, 255));
        jPanel41.setPreferredSize(new java.awt.Dimension(60, 269));

        javax.swing.GroupLayout jPanel41Layout = new javax.swing.GroupLayout(jPanel41);
        jPanel41.setLayout(jPanel41Layout);
        jPanel41Layout.setHorizontalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel41Layout.setVerticalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3508, Short.MAX_VALUE)
        );

        CreateMenu.add(jPanel41, java.awt.BorderLayout.LINE_START);

        jPanel42.setBackground(new java.awt.Color(255, 153, 153));
        jPanel42.setPreferredSize(new java.awt.Dimension(60, 269));

        javax.swing.GroupLayout jPanel42Layout = new javax.swing.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3508, Short.MAX_VALUE)
        );

        CreateMenu.add(jPanel42, java.awt.BorderLayout.LINE_END);

        jPanel43.setBackground(new java.awt.Color(255, 153, 153));
        jPanel43.setPreferredSize(new java.awt.Dimension(473, 60));

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3002, Short.MAX_VALUE)
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        CreateMenu.add(jPanel43, java.awt.BorderLayout.PAGE_END);

        jPanel31.setLayout(new java.awt.GridLayout(6, 3));

        jPanel93.setBackground(new java.awt.Color(253, 228, 228));
        jPanel93.setLayout(new java.awt.BorderLayout());

        jPanel126.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel126Layout = new javax.swing.GroupLayout(jPanel126);
        jPanel126.setLayout(jPanel126Layout);
        jPanel126Layout.setHorizontalGroup(
            jPanel126Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel126Layout.setVerticalGroup(
            jPanel126Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel93.add(jPanel126, java.awt.BorderLayout.PAGE_START);

        jPanel127.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel127Layout = new javax.swing.GroupLayout(jPanel127);
        jPanel127.setLayout(jPanel127Layout);
        jPanel127Layout.setHorizontalGroup(
            jPanel127Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel127Layout.setVerticalGroup(
            jPanel127Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel93.add(jPanel127, java.awt.BorderLayout.PAGE_END);

        jPanel128.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel128Layout = new javax.swing.GroupLayout(jPanel128);
        jPanel128.setLayout(jPanel128Layout);
        jPanel128Layout.setHorizontalGroup(
            jPanel128Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        jPanel128Layout.setVerticalGroup(
            jPanel128Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel93.add(jPanel128, java.awt.BorderLayout.LINE_START);

        jPanel129.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel129Layout = new javax.swing.GroupLayout(jPanel129);
        jPanel129.setLayout(jPanel129Layout);
        jPanel129Layout.setHorizontalGroup(
            jPanel129Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel129Layout.setVerticalGroup(
            jPanel129Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel93.add(jPanel129, java.awt.BorderLayout.LINE_END);

        jLabel11.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel11.setText("Name:");
        jLabel11.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel93.add(jLabel11, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel93);

        jPanel87.setBackground(new java.awt.Color(253, 228, 228));
        jPanel87.setLayout(new java.awt.BorderLayout());

        jPanel44.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel44Layout = new javax.swing.GroupLayout(jPanel44);
        jPanel44.setLayout(jPanel44Layout);
        jPanel44Layout.setHorizontalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel44Layout.setVerticalGroup(
            jPanel44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel87.add(jPanel44, java.awt.BorderLayout.PAGE_START);

        jPanel45.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel45Layout = new javax.swing.GroupLayout(jPanel45);
        jPanel45.setLayout(jPanel45Layout);
        jPanel45Layout.setHorizontalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel45Layout.setVerticalGroup(
            jPanel45Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel87.add(jPanel45, java.awt.BorderLayout.PAGE_END);

        jPanel46.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel46Layout = new javax.swing.GroupLayout(jPanel46);
        jPanel46.setLayout(jPanel46Layout);
        jPanel46Layout.setHorizontalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel46Layout.setVerticalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel87.add(jPanel46, java.awt.BorderLayout.LINE_START);

        jPanel105.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel105Layout = new javax.swing.GroupLayout(jPanel105);
        jPanel105.setLayout(jPanel105Layout);
        jPanel105Layout.setHorizontalGroup(
            jPanel105Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel105Layout.setVerticalGroup(
            jPanel105Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel87.add(jPanel105, java.awt.BorderLayout.LINE_END);

        TextNamefood.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel87.add(TextNamefood, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel87);

        jPanel88.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel88Layout = new javax.swing.GroupLayout(jPanel88);
        jPanel88.setLayout(jPanel88Layout);
        jPanel88Layout.setHorizontalGroup(
            jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel88Layout.setVerticalGroup(
            jPanel88Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 584, Short.MAX_VALUE)
        );

        jPanel31.add(jPanel88);

        jPanel89.setBackground(new java.awt.Color(253, 228, 228));
        jPanel89.setLayout(new java.awt.BorderLayout());

        jPanel130.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel130Layout = new javax.swing.GroupLayout(jPanel130);
        jPanel130.setLayout(jPanel130Layout);
        jPanel130Layout.setHorizontalGroup(
            jPanel130Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel130Layout.setVerticalGroup(
            jPanel130Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel89.add(jPanel130, java.awt.BorderLayout.PAGE_START);

        jPanel131.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel131Layout = new javax.swing.GroupLayout(jPanel131);
        jPanel131.setLayout(jPanel131Layout);
        jPanel131Layout.setHorizontalGroup(
            jPanel131Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel131Layout.setVerticalGroup(
            jPanel131Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel89.add(jPanel131, java.awt.BorderLayout.PAGE_END);

        jPanel132.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel132Layout = new javax.swing.GroupLayout(jPanel132);
        jPanel132.setLayout(jPanel132Layout);
        jPanel132Layout.setHorizontalGroup(
            jPanel132Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        jPanel132Layout.setVerticalGroup(
            jPanel132Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel89.add(jPanel132, java.awt.BorderLayout.LINE_START);

        jPanel133.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel133Layout = new javax.swing.GroupLayout(jPanel133);
        jPanel133.setLayout(jPanel133Layout);
        jPanel133Layout.setHorizontalGroup(
            jPanel133Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel133Layout.setVerticalGroup(
            jPanel133Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel89.add(jPanel133, java.awt.BorderLayout.LINE_END);

        jLabel12.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel12.setText("Type:");
        jLabel12.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel89.add(jLabel12, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel89);

        jPanel90.setBackground(new java.awt.Color(253, 228, 228));
        jPanel90.setLayout(new java.awt.BorderLayout());

        jPanel106.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel106Layout = new javax.swing.GroupLayout(jPanel106);
        jPanel106.setLayout(jPanel106Layout);
        jPanel106Layout.setHorizontalGroup(
            jPanel106Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel106Layout.setVerticalGroup(
            jPanel106Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel90.add(jPanel106, java.awt.BorderLayout.PAGE_START);

        jPanel107.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel107Layout = new javax.swing.GroupLayout(jPanel107);
        jPanel107.setLayout(jPanel107Layout);
        jPanel107Layout.setHorizontalGroup(
            jPanel107Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel107Layout.setVerticalGroup(
            jPanel107Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel90.add(jPanel107, java.awt.BorderLayout.PAGE_END);

        jPanel108.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel108Layout = new javax.swing.GroupLayout(jPanel108);
        jPanel108.setLayout(jPanel108Layout);
        jPanel108Layout.setHorizontalGroup(
            jPanel108Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel108Layout.setVerticalGroup(
            jPanel108Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel90.add(jPanel108, java.awt.BorderLayout.LINE_START);

        jPanel109.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel109Layout = new javax.swing.GroupLayout(jPanel109);
        jPanel109.setLayout(jPanel109Layout);
        jPanel109Layout.setHorizontalGroup(
            jPanel109Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel109Layout.setVerticalGroup(
            jPanel109Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel90.add(jPanel109, java.awt.BorderLayout.LINE_END);

        SelectTypefood.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel90.add(SelectTypefood, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel90);

        jPanel91.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel91Layout = new javax.swing.GroupLayout(jPanel91);
        jPanel91.setLayout(jPanel91Layout);
        jPanel91Layout.setHorizontalGroup(
            jPanel91Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel91Layout.setVerticalGroup(
            jPanel91Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 584, Short.MAX_VALUE)
        );

        jPanel31.add(jPanel91);

        jPanel92.setBackground(new java.awt.Color(253, 228, 228));
        jPanel92.setLayout(new java.awt.BorderLayout());

        jPanel134.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel134Layout = new javax.swing.GroupLayout(jPanel134);
        jPanel134.setLayout(jPanel134Layout);
        jPanel134Layout.setHorizontalGroup(
            jPanel134Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel134Layout.setVerticalGroup(
            jPanel134Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel92.add(jPanel134, java.awt.BorderLayout.PAGE_START);

        jPanel135.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel135Layout = new javax.swing.GroupLayout(jPanel135);
        jPanel135.setLayout(jPanel135Layout);
        jPanel135Layout.setHorizontalGroup(
            jPanel135Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel135Layout.setVerticalGroup(
            jPanel135Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel92.add(jPanel135, java.awt.BorderLayout.PAGE_END);

        jPanel136.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel136Layout = new javax.swing.GroupLayout(jPanel136);
        jPanel136.setLayout(jPanel136Layout);
        jPanel136Layout.setHorizontalGroup(
            jPanel136Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        jPanel136Layout.setVerticalGroup(
            jPanel136Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel92.add(jPanel136, java.awt.BorderLayout.LINE_START);

        jPanel137.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel137Layout = new javax.swing.GroupLayout(jPanel137);
        jPanel137.setLayout(jPanel137Layout);
        jPanel137Layout.setHorizontalGroup(
            jPanel137Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel137Layout.setVerticalGroup(
            jPanel137Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel92.add(jPanel137, java.awt.BorderLayout.LINE_END);

        jLabel13.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel13.setText("ID:");
        jLabel13.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel92.add(jLabel13, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel92);

        jPanel94.setBackground(new java.awt.Color(253, 228, 228));
        jPanel94.setLayout(new java.awt.BorderLayout());

        jPanel110.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel110Layout = new javax.swing.GroupLayout(jPanel110);
        jPanel110.setLayout(jPanel110Layout);
        jPanel110Layout.setHorizontalGroup(
            jPanel110Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel110Layout.setVerticalGroup(
            jPanel110Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel94.add(jPanel110, java.awt.BorderLayout.PAGE_START);

        jPanel111.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel111Layout = new javax.swing.GroupLayout(jPanel111);
        jPanel111.setLayout(jPanel111Layout);
        jPanel111Layout.setHorizontalGroup(
            jPanel111Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel111Layout.setVerticalGroup(
            jPanel111Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel94.add(jPanel111, java.awt.BorderLayout.PAGE_END);

        jPanel112.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel112Layout = new javax.swing.GroupLayout(jPanel112);
        jPanel112.setLayout(jPanel112Layout);
        jPanel112Layout.setHorizontalGroup(
            jPanel112Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel112Layout.setVerticalGroup(
            jPanel112Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel94.add(jPanel112, java.awt.BorderLayout.LINE_START);

        jPanel113.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel113Layout = new javax.swing.GroupLayout(jPanel113);
        jPanel113.setLayout(jPanel113Layout);
        jPanel113Layout.setHorizontalGroup(
            jPanel113Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel113Layout.setVerticalGroup(
            jPanel113Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel94.add(jPanel113, java.awt.BorderLayout.LINE_END);

        TextID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextIDActionPerformed(evt);
            }
        });
        jPanel94.add(TextID, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel94);

        jPanel95.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel95Layout = new javax.swing.GroupLayout(jPanel95);
        jPanel95.setLayout(jPanel95Layout);
        jPanel95Layout.setHorizontalGroup(
            jPanel95Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel95Layout.setVerticalGroup(
            jPanel95Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 584, Short.MAX_VALUE)
        );

        jPanel31.add(jPanel95);

        jPanel96.setBackground(new java.awt.Color(253, 228, 228));
        jPanel96.setLayout(new java.awt.BorderLayout());

        jPanel138.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel138Layout = new javax.swing.GroupLayout(jPanel138);
        jPanel138.setLayout(jPanel138Layout);
        jPanel138Layout.setHorizontalGroup(
            jPanel138Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel138Layout.setVerticalGroup(
            jPanel138Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel96.add(jPanel138, java.awt.BorderLayout.PAGE_START);

        jPanel139.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel139Layout = new javax.swing.GroupLayout(jPanel139);
        jPanel139.setLayout(jPanel139Layout);
        jPanel139Layout.setHorizontalGroup(
            jPanel139Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel139Layout.setVerticalGroup(
            jPanel139Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel96.add(jPanel139, java.awt.BorderLayout.PAGE_END);

        jPanel140.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel140Layout = new javax.swing.GroupLayout(jPanel140);
        jPanel140.setLayout(jPanel140Layout);
        jPanel140Layout.setHorizontalGroup(
            jPanel140Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        jPanel140Layout.setVerticalGroup(
            jPanel140Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel96.add(jPanel140, java.awt.BorderLayout.LINE_START);

        jPanel141.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel141Layout = new javax.swing.GroupLayout(jPanel141);
        jPanel141.setLayout(jPanel141Layout);
        jPanel141Layout.setHorizontalGroup(
            jPanel141Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel141Layout.setVerticalGroup(
            jPanel141Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel96.add(jPanel141, java.awt.BorderLayout.LINE_END);

        jLabel20.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel20.setText("Price:");
        jLabel20.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel96.add(jLabel20, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel96);

        jPanel97.setBackground(new java.awt.Color(253, 228, 228));
        jPanel97.setLayout(new java.awt.BorderLayout());

        jPanel114.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel114Layout = new javax.swing.GroupLayout(jPanel114);
        jPanel114.setLayout(jPanel114Layout);
        jPanel114Layout.setHorizontalGroup(
            jPanel114Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel114Layout.setVerticalGroup(
            jPanel114Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel97.add(jPanel114, java.awt.BorderLayout.PAGE_START);

        jPanel115.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel115Layout = new javax.swing.GroupLayout(jPanel115);
        jPanel115.setLayout(jPanel115Layout);
        jPanel115Layout.setHorizontalGroup(
            jPanel115Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel115Layout.setVerticalGroup(
            jPanel115Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel97.add(jPanel115, java.awt.BorderLayout.PAGE_END);

        jPanel116.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel116Layout = new javax.swing.GroupLayout(jPanel116);
        jPanel116.setLayout(jPanel116Layout);
        jPanel116Layout.setHorizontalGroup(
            jPanel116Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel116Layout.setVerticalGroup(
            jPanel116Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel97.add(jPanel116, java.awt.BorderLayout.LINE_START);

        jPanel117.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel117Layout = new javax.swing.GroupLayout(jPanel117);
        jPanel117.setLayout(jPanel117Layout);
        jPanel117Layout.setHorizontalGroup(
            jPanel117Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel117Layout.setVerticalGroup(
            jPanel117Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel97.add(jPanel117, java.awt.BorderLayout.LINE_END);
        jPanel97.add(TextPrice, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel97);

        jPanel98.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel98Layout = new javax.swing.GroupLayout(jPanel98);
        jPanel98.setLayout(jPanel98Layout);
        jPanel98Layout.setHorizontalGroup(
            jPanel98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel98Layout.setVerticalGroup(
            jPanel98Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 584, Short.MAX_VALUE)
        );

        jPanel31.add(jPanel98);

        jPanel99.setBackground(new java.awt.Color(253, 228, 228));
        jPanel99.setLayout(new java.awt.BorderLayout());

        jPanel142.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel142Layout = new javax.swing.GroupLayout(jPanel142);
        jPanel142.setLayout(jPanel142Layout);
        jPanel142Layout.setHorizontalGroup(
            jPanel142Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel142Layout.setVerticalGroup(
            jPanel142Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel99.add(jPanel142, java.awt.BorderLayout.PAGE_START);

        jPanel143.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel143Layout = new javax.swing.GroupLayout(jPanel143);
        jPanel143.setLayout(jPanel143Layout);
        jPanel143Layout.setHorizontalGroup(
            jPanel143Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel143Layout.setVerticalGroup(
            jPanel143Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel99.add(jPanel143, java.awt.BorderLayout.PAGE_END);

        jPanel144.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel144Layout = new javax.swing.GroupLayout(jPanel144);
        jPanel144.setLayout(jPanel144Layout);
        jPanel144Layout.setHorizontalGroup(
            jPanel144Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 240, Short.MAX_VALUE)
        );
        jPanel144Layout.setVerticalGroup(
            jPanel144Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel99.add(jPanel144, java.awt.BorderLayout.LINE_START);

        jPanel145.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel145Layout = new javax.swing.GroupLayout(jPanel145);
        jPanel145.setLayout(jPanel145Layout);
        jPanel145Layout.setHorizontalGroup(
            jPanel145Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel145Layout.setVerticalGroup(
            jPanel145Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel99.add(jPanel145, java.awt.BorderLayout.LINE_END);

        jLabel37.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        jLabel37.setText("Image:");
        jLabel37.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel99.add(jLabel37, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel99);

        jPanel100.setBackground(new java.awt.Color(253, 228, 228));
        jPanel100.setLayout(new java.awt.BorderLayout());

        jPanel118.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel118Layout = new javax.swing.GroupLayout(jPanel118);
        jPanel118.setLayout(jPanel118Layout);
        jPanel118Layout.setHorizontalGroup(
            jPanel118Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel118Layout.setVerticalGroup(
            jPanel118Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel100.add(jPanel118, java.awt.BorderLayout.PAGE_START);

        jPanel119.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel119Layout = new javax.swing.GroupLayout(jPanel119);
        jPanel119.setLayout(jPanel119Layout);
        jPanel119Layout.setHorizontalGroup(
            jPanel119Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel119Layout.setVerticalGroup(
            jPanel119Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 35, Short.MAX_VALUE)
        );

        jPanel100.add(jPanel119, java.awt.BorderLayout.PAGE_END);

        jPanel120.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel120Layout = new javax.swing.GroupLayout(jPanel120);
        jPanel120.setLayout(jPanel120Layout);
        jPanel120Layout.setHorizontalGroup(
            jPanel120Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel120Layout.setVerticalGroup(
            jPanel120Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel100.add(jPanel120, java.awt.BorderLayout.LINE_START);

        jPanel121.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel121Layout = new javax.swing.GroupLayout(jPanel121);
        jPanel121.setLayout(jPanel121Layout);
        jPanel121Layout.setHorizontalGroup(
            jPanel121Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 15, Short.MAX_VALUE)
        );
        jPanel121Layout.setVerticalGroup(
            jPanel121Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel100.add(jPanel121, java.awt.BorderLayout.LINE_END);
        jPanel100.add(Textnamephoto, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel100);

        jPanel101.setBackground(new java.awt.Color(253, 228, 228));
        jPanel101.setLayout(new java.awt.BorderLayout());

        jPanel146.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel146Layout = new javax.swing.GroupLayout(jPanel146);
        jPanel146.setLayout(jPanel146Layout);
        jPanel146Layout.setHorizontalGroup(
            jPanel146Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel146Layout.setVerticalGroup(
            jPanel146Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel101.add(jPanel146, java.awt.BorderLayout.PAGE_START);

        jPanel147.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel147Layout = new javax.swing.GroupLayout(jPanel147);
        jPanel147.setLayout(jPanel147Layout);
        jPanel147Layout.setHorizontalGroup(
            jPanel147Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel147Layout.setVerticalGroup(
            jPanel147Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        jPanel101.add(jPanel147, java.awt.BorderLayout.PAGE_END);

        jPanel148.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel148Layout = new javax.swing.GroupLayout(jPanel148);
        jPanel148.setLayout(jPanel148Layout);
        jPanel148Layout.setHorizontalGroup(
            jPanel148Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );
        jPanel148Layout.setVerticalGroup(
            jPanel148Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel101.add(jPanel148, java.awt.BorderLayout.LINE_START);

        jPanel149.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel149Layout = new javax.swing.GroupLayout(jPanel149);
        jPanel149.setLayout(jPanel149Layout);
        jPanel149Layout.setHorizontalGroup(
            jPanel149Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 201, Short.MAX_VALUE)
        );
        jPanel149Layout.setVerticalGroup(
            jPanel149Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel101.add(jPanel149, java.awt.BorderLayout.LINE_END);

        Addphotobutton.setBackground(new java.awt.Color(234, 225, 239));
        Addphotobutton.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        Addphotobutton.setForeground(new java.awt.Color(146, 22, 22));
        Addphotobutton.setText("Browse");
        Addphotobutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddphotobuttonActionPerformed(evt);
            }
        });
        jPanel101.add(Addphotobutton, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel101);

        jPanel102.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel102Layout = new javax.swing.GroupLayout(jPanel102);
        jPanel102.setLayout(jPanel102Layout);
        jPanel102Layout.setHorizontalGroup(
            jPanel102Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel102Layout.setVerticalGroup(
            jPanel102Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 584, Short.MAX_VALUE)
        );

        jPanel31.add(jPanel102);

        jPanel103.setBackground(new java.awt.Color(253, 228, 228));
        jPanel103.setLayout(new java.awt.BorderLayout());

        jPanel122.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel122Layout = new javax.swing.GroupLayout(jPanel122);
        jPanel122.setLayout(jPanel122Layout);
        jPanel122Layout.setHorizontalGroup(
            jPanel122Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel122Layout.setVerticalGroup(
            jPanel122Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 25, Short.MAX_VALUE)
        );

        jPanel103.add(jPanel122, java.awt.BorderLayout.PAGE_START);

        jPanel123.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel123Layout = new javax.swing.GroupLayout(jPanel123);
        jPanel123.setLayout(jPanel123Layout);
        jPanel123Layout.setHorizontalGroup(
            jPanel123Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel123Layout.setVerticalGroup(
            jPanel123Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 25, Short.MAX_VALUE)
        );

        jPanel103.add(jPanel123, java.awt.BorderLayout.PAGE_END);

        jPanel124.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel124Layout = new javax.swing.GroupLayout(jPanel124);
        jPanel124.setLayout(jPanel124Layout);
        jPanel124Layout.setHorizontalGroup(
            jPanel124Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );
        jPanel124Layout.setVerticalGroup(
            jPanel124Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel103.add(jPanel124, java.awt.BorderLayout.LINE_START);

        jPanel125.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel125Layout = new javax.swing.GroupLayout(jPanel125);
        jPanel125.setLayout(jPanel125Layout);
        jPanel125Layout.setHorizontalGroup(
            jPanel125Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 65, Short.MAX_VALUE)
        );
        jPanel125Layout.setVerticalGroup(
            jPanel125Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel103.add(jPanel125, java.awt.BorderLayout.LINE_END);

        AddMenuButton.setBackground(new java.awt.Color(219, 199, 231));
        AddMenuButton.setFont(new java.awt.Font("Tw Cen MT", 1, 24)); // NOI18N
        AddMenuButton.setForeground(new java.awt.Color(146, 22, 22));
        AddMenuButton.setText("ADD");
        AddMenuButton.setToolTipText("");
        AddMenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddMenuButtonActionPerformed(evt);
            }
        });
        jPanel103.add(AddMenuButton, java.awt.BorderLayout.CENTER);

        jPanel31.add(jPanel103);

        jPanel104.setBackground(new java.awt.Color(253, 228, 228));

        javax.swing.GroupLayout jPanel104Layout = new javax.swing.GroupLayout(jPanel104);
        jPanel104.setLayout(jPanel104Layout);
        jPanel104Layout.setHorizontalGroup(
            jPanel104Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 960, Short.MAX_VALUE)
        );
        jPanel104Layout.setVerticalGroup(
            jPanel104Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 584, Short.MAX_VALUE)
        );

        jPanel31.add(jPanel104);

        CreateMenu.add(jPanel31, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(CreateMenu, "card2");

        DrinksMenu.setBackground(new java.awt.Color(255, 255, 255));
        DrinksMenu.setLayout(new java.awt.BorderLayout());

        jPanel47.setBackground(new java.awt.Color(255, 153, 153));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Drinks");
        jPanel47.add(jLabel14);

        DrinksMenu.add(jPanel47, java.awt.BorderLayout.PAGE_START);

        DRMscroll.setPreferredSize(new java.awt.Dimension(1380, 500));

        PageforDrinksMenu.setBackground(new java.awt.Color(255, 255, 255));
        PageforDrinksMenu.setPreferredSize(new java.awt.Dimension(1380, 5000));
        PageforDrinksMenu.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        DRMscroll.setViewportView(PageforDrinksMenu);

        DrinksMenu.add(DRMscroll, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(DrinksMenu, "card3");

        MaincourseMenu.setLayout(new java.awt.BorderLayout());

        jPanel48.setBackground(new java.awt.Color(255, 153, 153));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Maincourse");
        jPanel48.add(jLabel15);

        MaincourseMenu.add(jPanel48, java.awt.BorderLayout.PAGE_START);

        jPanel49.setBackground(new java.awt.Color(255, 255, 255));
        jPanel49.setLayout(new java.awt.BorderLayout());

        MCMscroll.setPreferredSize(new java.awt.Dimension(1380, 500));

        PageforMaincourseMenu.setBackground(new java.awt.Color(255, 255, 255));
        PageforMaincourseMenu.setPreferredSize(new java.awt.Dimension(1380, 5000));
        PageforMaincourseMenu.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        MCMscroll.setViewportView(PageforMaincourseMenu);

        jPanel49.add(MCMscroll, java.awt.BorderLayout.CENTER);

        MaincourseMenu.add(jPanel49, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(MaincourseMenu, "card4");

        DessertMenu.setLayout(new java.awt.BorderLayout());

        jPanel50.setBackground(new java.awt.Color(255, 153, 153));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Dessert");
        jPanel50.add(jLabel16);

        DessertMenu.add(jPanel50, java.awt.BorderLayout.PAGE_START);

        jPanel51.setBackground(new java.awt.Color(255, 255, 255));
        jPanel51.setLayout(new java.awt.BorderLayout());

        DSMscroll.setPreferredSize(new java.awt.Dimension(1380, 500));

        PageforDessertMenu.setBackground(new java.awt.Color(255, 255, 255));
        PageforDessertMenu.setPreferredSize(new java.awt.Dimension(1380, 5000));
        PageforDessertMenu.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        DSMscroll.setViewportView(PageforDessertMenu);

        jPanel51.add(DSMscroll, java.awt.BorderLayout.CENTER);

        DessertMenu.add(jPanel51, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(DessertMenu, "card5");

        DrinksStock.setLayout(new java.awt.BorderLayout());

        jPanel52.setBackground(new java.awt.Color(255, 153, 153));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Drinks Stock");
        jPanel52.add(jLabel17);

        DrinksStock.add(jPanel52, java.awt.BorderLayout.PAGE_START);

        jPanel53.setBackground(new java.awt.Color(255, 255, 255));
        jPanel53.setLayout(new java.awt.BorderLayout());

        DRTscroll.setHorizontalScrollBar(null);
        DRTscroll.setPreferredSize(new java.awt.Dimension(1380, 500));

        PageforDrinksStock.setBackground(new java.awt.Color(255, 255, 255));
        PageforDrinksStock.setPreferredSize(new java.awt.Dimension(1380, 5000));
        PageforDrinksStock.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        DRTscroll.setViewportView(PageforDrinksStock);

        jPanel53.add(DRTscroll, java.awt.BorderLayout.CENTER);

        DrinksStock.add(jPanel53, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(DrinksStock, "card6");

        MaincourseStock.setBackground(new java.awt.Color(255, 153, 153));
        MaincourseStock.setLayout(new java.awt.BorderLayout());

        jPanel54.setBackground(new java.awt.Color(255, 153, 153));

        jLabel21.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Maincourse Stock");
        jPanel54.add(jLabel21);

        MaincourseStock.add(jPanel54, java.awt.BorderLayout.PAGE_START);

        jPanel55.setBackground(new java.awt.Color(255, 255, 255));
        jPanel55.setLayout(new java.awt.BorderLayout());

        MCTscroll.setBackground(new java.awt.Color(255, 255, 255));
        MCTscroll.setPreferredSize(new java.awt.Dimension(1380, 500));

        PageforMaincourseStock.setBackground(new java.awt.Color(255, 255, 255));
        PageforMaincourseStock.setPreferredSize(new java.awt.Dimension(1380, 5000));
        PageforMaincourseStock.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        MCTscroll.setViewportView(PageforMaincourseStock);

        jPanel55.add(MCTscroll, java.awt.BorderLayout.CENTER);

        MaincourseStock.add(jPanel55, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(MaincourseStock, "card7");

        DessertStock.setBackground(new java.awt.Color(255, 153, 153));
        DessertStock.setLayout(new java.awt.BorderLayout());

        jPanel56.setBackground(new java.awt.Color(255, 153, 153));

        jLabel22.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Dessert Stock");
        jPanel56.add(jLabel22);

        DessertStock.add(jPanel56, java.awt.BorderLayout.PAGE_START);

        jPanel57.setBackground(new java.awt.Color(255, 255, 255));
        jPanel57.setLayout(new java.awt.BorderLayout());

        DSTscroll.setPreferredSize(new java.awt.Dimension(1380, 500));

        PageforDessertStock.setBackground(new java.awt.Color(255, 255, 255));
        PageforDessertStock.setPreferredSize(new java.awt.Dimension(1380, 5000));
        PageforDessertStock.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        DSTscroll.setViewportView(PageforDessertStock);

        jPanel57.add(DSTscroll, java.awt.BorderLayout.CENTER);

        DessertStock.add(jPanel57, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(DessertStock, "card8");

        DeletePanel.setLayout(new java.awt.BorderLayout());

        jPanel85.setBackground(new java.awt.Color(0, 153, 153));

        jLabel39.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Delete");
        jPanel85.add(jLabel39);

        DeletePanel.add(jPanel85, java.awt.BorderLayout.PAGE_START);

        jPanel86.setBackground(new java.awt.Color(255, 255, 255));
        jPanel86.setLayout(new java.awt.BorderLayout());

        PageforDelete.setBackground(new java.awt.Color(255, 255, 255));
        PageforDelete.setLayout(new java.awt.GridLayout(0, 3));
        jScrollPane16.setViewportView(PageforDelete);

        jPanel86.add(jScrollPane16, java.awt.BorderLayout.CENTER);

        DeletePanel.add(jPanel86, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(DeletePanel, "card4");

        ManagePromotion.setLayout(new java.awt.BorderLayout());

        jPanel58.setBackground(new java.awt.Color(255, 153, 153));

        jLabel23.setFont(new java.awt.Font("Tw Cen MT", 1, 48)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Manage Promotion");
        jPanel58.add(jLabel23);

        ManagePromotion.add(jPanel58, java.awt.BorderLayout.PAGE_START);

        jPanel59.setLayout(new java.awt.BorderLayout());

        jPanel60.setBackground(new java.awt.Color(255, 153, 153));
        jPanel60.setPreferredSize(new java.awt.Dimension(517, 60));
        jPanel60.setLayout(new java.awt.GridBagLayout());

        jButton13.setBackground(new java.awt.Color(219, 199, 231));
        jButton13.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jButton13.setForeground(new java.awt.Color(146, 22, 22));
        jButton13.setText("Drinks");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 20;
        gridBagConstraints.ipady = 10;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 100);
        jPanel60.add(jButton13, gridBagConstraints);

        jButton14.setBackground(new java.awt.Color(219, 199, 231));
        jButton14.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jButton14.setForeground(new java.awt.Color(146, 22, 22));
        jButton14.setText("Maincourse");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 20;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 100);
        jPanel60.add(jButton14, gridBagConstraints);

        jButton15.setBackground(new java.awt.Color(219, 199, 231));
        jButton15.setFont(new java.awt.Font("Tw Cen MT", 0, 24)); // NOI18N
        jButton15.setForeground(new java.awt.Color(146, 22, 22));
        jButton15.setText("Dessert");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 20;
        jPanel60.add(jButton15, gridBagConstraints);

        jPanel59.add(jPanel60, java.awt.BorderLayout.PAGE_START);

        ManagePromotionPage.setLayout(new java.awt.CardLayout());

        PromotionDrinks.setLayout(new java.awt.BorderLayout());

        jPanel65.setBackground(new java.awt.Color(253, 212, 212));

        jLabel24.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Drinks");
        jPanel65.add(jLabel24);

        PromotionDrinks.add(jPanel65, java.awt.BorderLayout.PAGE_START);

        jPanel66.setBackground(new java.awt.Color(253, 212, 212));

        javax.swing.GroupLayout jPanel66Layout = new javax.swing.GroupLayout(jPanel66);
        jPanel66.setLayout(jPanel66Layout);
        jPanel66Layout.setHorizontalGroup(
            jPanel66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel66Layout.setVerticalGroup(
            jPanel66Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3354, Short.MAX_VALUE)
        );

        PromotionDrinks.add(jPanel66, java.awt.BorderLayout.LINE_START);

        jPanel68.setBackground(new java.awt.Color(253, 212, 212));

        javax.swing.GroupLayout jPanel68Layout = new javax.swing.GroupLayout(jPanel68);
        jPanel68.setLayout(jPanel68Layout);
        jPanel68Layout.setHorizontalGroup(
            jPanel68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel68Layout.setVerticalGroup(
            jPanel68Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3354, Short.MAX_VALUE)
        );

        PromotionDrinks.add(jPanel68, java.awt.BorderLayout.LINE_END);

        javax.swing.GroupLayout jPanel69Layout = new javax.swing.GroupLayout(jPanel69);
        jPanel69.setLayout(jPanel69Layout);
        jPanel69Layout.setHorizontalGroup(
            jPanel69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3002, Short.MAX_VALUE)
        );
        jPanel69Layout.setVerticalGroup(
            jPanel69Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        PromotionDrinks.add(jPanel69, java.awt.BorderLayout.PAGE_END);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setLayout(new java.awt.BorderLayout());

        jScrollPane12.setForeground(new java.awt.Color(255, 255, 255));

        TableDrinks.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        TableDrinks.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Name", "Id", "Price", "Typefood"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane12.setViewportView(TableDrinks);
        if (TableDrinks.getColumnModel().getColumnCount() > 0) {
            TableDrinks.getColumnModel().getColumn(0).setResizable(false);
            TableDrinks.getColumnModel().getColumn(1).setResizable(false);
            TableDrinks.getColumnModel().getColumn(2).setResizable(false);
            TableDrinks.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel10.add(jScrollPane12, java.awt.BorderLayout.CENTER);

        DrinksUpdate.setBackground(new java.awt.Color(253, 212, 212));
        DrinksUpdate.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        DrinksUpdate.setForeground(new java.awt.Color(146, 22, 22));
        DrinksUpdate.setText("Update");
        DrinksUpdate.setBorderPainted(false);
        DrinksUpdate.setFocusPainted(false);
        DrinksUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DrinksUpdateActionPerformed(evt);
            }
        });
        jPanel10.add(DrinksUpdate, java.awt.BorderLayout.PAGE_END);

        PromotionDrinks.add(jPanel10, java.awt.BorderLayout.CENTER);

        ManagePromotionPage.add(PromotionDrinks, "card2");

        PromotionMaincourse.setLayout(new java.awt.BorderLayout());

        jPanel67.setBackground(new java.awt.Color(253, 212, 212));

        jLabel25.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Maincourse");
        jPanel67.add(jLabel25);

        PromotionMaincourse.add(jPanel67, java.awt.BorderLayout.PAGE_START);

        jPanel70.setBackground(new java.awt.Color(253, 212, 212));

        javax.swing.GroupLayout jPanel70Layout = new javax.swing.GroupLayout(jPanel70);
        jPanel70.setLayout(jPanel70Layout);
        jPanel70Layout.setHorizontalGroup(
            jPanel70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel70Layout.setVerticalGroup(
            jPanel70Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3354, Short.MAX_VALUE)
        );

        PromotionMaincourse.add(jPanel70, java.awt.BorderLayout.LINE_START);

        jPanel71.setBackground(new java.awt.Color(253, 212, 212));

        javax.swing.GroupLayout jPanel71Layout = new javax.swing.GroupLayout(jPanel71);
        jPanel71.setLayout(jPanel71Layout);
        jPanel71Layout.setHorizontalGroup(
            jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel71Layout.setVerticalGroup(
            jPanel71Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3354, Short.MAX_VALUE)
        );

        PromotionMaincourse.add(jPanel71, java.awt.BorderLayout.LINE_END);

        javax.swing.GroupLayout jPanel72Layout = new javax.swing.GroupLayout(jPanel72);
        jPanel72.setLayout(jPanel72Layout);
        jPanel72Layout.setHorizontalGroup(
            jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3002, Short.MAX_VALUE)
        );
        jPanel72Layout.setVerticalGroup(
            jPanel72Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        PromotionMaincourse.add(jPanel72, java.awt.BorderLayout.PAGE_END);

        jPanel61.setBackground(new java.awt.Color(255, 255, 255));
        jPanel61.setLayout(new java.awt.BorderLayout());

        jScrollPane13.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane13.setForeground(new java.awt.Color(255, 255, 255));

        TableMaincourse.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        TableMaincourse.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Name", "Id", "Price", "Typefood"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane13.setViewportView(TableMaincourse);
        if (TableMaincourse.getColumnModel().getColumnCount() > 0) {
            TableMaincourse.getColumnModel().getColumn(0).setResizable(false);
            TableMaincourse.getColumnModel().getColumn(1).setResizable(false);
            TableMaincourse.getColumnModel().getColumn(2).setResizable(false);
            TableMaincourse.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel61.add(jScrollPane13, java.awt.BorderLayout.CENTER);

        MaincourseUpdate.setBackground(new java.awt.Color(253, 212, 212));
        MaincourseUpdate.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        MaincourseUpdate.setForeground(new java.awt.Color(146, 22, 22));
        MaincourseUpdate.setText("Update");
        MaincourseUpdate.setBorderPainted(false);
        MaincourseUpdate.setFocusPainted(false);
        MaincourseUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MaincourseUpdateActionPerformed(evt);
            }
        });
        jPanel61.add(MaincourseUpdate, java.awt.BorderLayout.PAGE_END);

        PromotionMaincourse.add(jPanel61, java.awt.BorderLayout.CENTER);

        ManagePromotionPage.add(PromotionMaincourse, "card2");

        PromotionDessert.setLayout(new java.awt.BorderLayout());

        jPanel73.setBackground(new java.awt.Color(253, 212, 212));

        jLabel26.setFont(new java.awt.Font("Tw Cen MT", 1, 36)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Dessert");
        jPanel73.add(jLabel26);

        PromotionDessert.add(jPanel73, java.awt.BorderLayout.PAGE_START);

        jPanel74.setBackground(new java.awt.Color(253, 212, 212));

        javax.swing.GroupLayout jPanel74Layout = new javax.swing.GroupLayout(jPanel74);
        jPanel74.setLayout(jPanel74Layout);
        jPanel74Layout.setHorizontalGroup(
            jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel74Layout.setVerticalGroup(
            jPanel74Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3354, Short.MAX_VALUE)
        );

        PromotionDessert.add(jPanel74, java.awt.BorderLayout.LINE_START);

        jPanel75.setBackground(new java.awt.Color(253, 212, 212));

        javax.swing.GroupLayout jPanel75Layout = new javax.swing.GroupLayout(jPanel75);
        jPanel75.setLayout(jPanel75Layout);
        jPanel75Layout.setHorizontalGroup(
            jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel75Layout.setVerticalGroup(
            jPanel75Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3354, Short.MAX_VALUE)
        );

        PromotionDessert.add(jPanel75, java.awt.BorderLayout.LINE_END);

        javax.swing.GroupLayout jPanel76Layout = new javax.swing.GroupLayout(jPanel76);
        jPanel76.setLayout(jPanel76Layout);
        jPanel76Layout.setHorizontalGroup(
            jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 3002, Short.MAX_VALUE)
        );
        jPanel76Layout.setVerticalGroup(
            jPanel76Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        PromotionDessert.add(jPanel76, java.awt.BorderLayout.PAGE_END);

        jPanel62.setBackground(new java.awt.Color(255, 255, 255));
        jPanel62.setLayout(new java.awt.BorderLayout());

        jScrollPane14.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane14.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane14.setFont(new java.awt.Font("Tw Cen MT", 1, 18)); // NOI18N

        TableDessert.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        TableDessert.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Name", "Id", "Price", "Typefood"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane14.setViewportView(TableDessert);
        if (TableDessert.getColumnModel().getColumnCount() > 0) {
            TableDessert.getColumnModel().getColumn(0).setResizable(false);
            TableDessert.getColumnModel().getColumn(1).setResizable(false);
            TableDessert.getColumnModel().getColumn(2).setResizable(false);
            TableDessert.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel62.add(jScrollPane14, java.awt.BorderLayout.CENTER);

        DessertUpdate.setBackground(new java.awt.Color(253, 212, 212));
        DessertUpdate.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        DessertUpdate.setForeground(new java.awt.Color(146, 22, 22));
        DessertUpdate.setText("Update");
        DessertUpdate.setBorderPainted(false);
        DessertUpdate.setFocusPainted(false);
        DessertUpdate.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DessertUpdateMouseClicked(evt);
            }
        });
        DessertUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DessertUpdateActionPerformed(evt);
            }
        });
        jPanel62.add(DessertUpdate, java.awt.BorderLayout.PAGE_END);

        PromotionDessert.add(jPanel62, java.awt.BorderLayout.CENTER);

        ManagePromotionPage.add(PromotionDessert, "card2");

        jPanel59.add(ManagePromotionPage, java.awt.BorderLayout.CENTER);

        ManagePromotion.add(jPanel59, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(ManagePromotion, "card10");

        ManageMenuPage.add(ManagePageSetting, java.awt.BorderLayout.CENTER);

        Allpage.add(ManageMenuPage, "card3");

        getContentPane().add(Allpage, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void QueueButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QueueButtonActionPerformed
        ManagePage.removeAll();
        ManagePage.add(QueuePage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_QueueButtonActionPerformed

    private void DrinksButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DrinksButtonActionPerformed
        ManagePage.removeAll();
        ManagePage.add(DrinksPage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_DrinksButtonActionPerformed

    private void MaincourseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MaincourseButtonActionPerformed
        ManagePage.removeAll();
        ManagePage.add(MaincoursePage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_MaincourseButtonActionPerformed

    private void DessertButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DessertButtonActionPerformed
        ManagePage.removeAll();
        ManagePage.add(DessertPage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_DessertButtonActionPerformed

    private void QueueButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_QueueButtonMouseClicked

    }//GEN-LAST:event_QueueButtonMouseClicked

    private void DrinksButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DrinksButtonMouseClicked

    }//GEN-LAST:event_DrinksButtonMouseClicked

    private void MaincourseButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MaincourseButtonMouseClicked

    }//GEN-LAST:event_MaincourseButtonMouseClicked

    private void DessertButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DessertButtonMouseClicked

    }//GEN-LAST:event_DessertButtonMouseClicked

    private void ExitGui1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitGui1ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExitGui1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        Allpage.removeAll();
        Allpage.add(ManageMenuPage);
        Allpage.repaint();
        Allpage.revalidate();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void CartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartButtonActionPerformed
        ManagePage.removeAll();
        ManagePage.add(CartPage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_CartButtonActionPerformed

    private void CartButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CartButtonMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_CartButtonMouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:

        Allpage.removeAll();
        Allpage.add(jPanel30);
        Allpage.repaint();
        Allpage.revalidate();

    }//GEN-LAST:event_jButton4ActionPerformed

    private void CreateMenubtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreateMenubtnActionPerformed

        ManagePageSetting.removeAll();
        ManagePageSetting.add(CreateMenu);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_CreateMenubtnActionPerformed

    private void DrinkmenubtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DrinkmenubtnActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(DrinksMenu);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_DrinkmenubtnActionPerformed

    private void MaincoursemenubtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MaincoursemenubtnActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(MaincourseMenu);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_MaincoursemenubtnActionPerformed

    private void DessertmenubtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DessertmenubtnActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(DessertMenu);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_DessertmenubtnActionPerformed

    private void DrinkstockbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DrinkstockbtnActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(DrinksStock);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_DrinkstockbtnActionPerformed

    private void MaincoursestockbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MaincoursestockbtnActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(MaincourseStock);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_MaincoursestockbtnActionPerformed

    private void DessertstockbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DessertstockbtnActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(DessertStock);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_DessertstockbtnActionPerformed

    private void PromotionbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PromotionbtnActionPerformed
        ManagePageSetting.removeAll();
        ManagePageSetting.add(ManagePromotion);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_PromotionbtnActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
        ManagePromotionPage.removeAll();
        ManagePromotionPage.add(PromotionDrinks);
        ManagePromotionPage.repaint();
        ManagePromotionPage.revalidate();
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
        ManagePromotionPage.removeAll();
        ManagePromotionPage.add(PromotionMaincourse);
        ManagePromotionPage.repaint();
        ManagePromotionPage.revalidate();
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
        ManagePromotionPage.removeAll();
        ManagePromotionPage.add(PromotionDessert);
        ManagePromotionPage.repaint();
        ManagePromotionPage.revalidate();
    }//GEN-LAST:event_jButton15ActionPerformed

    private void DessertUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DessertUpdateActionPerformed

        for (int i = 0; i < DessertPromotion.getRowCount(); i++) {
            String name = DessertPromotion.getValueAt(i, 0).toString();
            String id = DessertPromotion.getValueAt(i, 1).toString();
            String price = DessertPromotion.getValueAt(i, 2).toString();
            String type = DessertPromotion.getValueAt(i, 3).toString();
            UpdatepPromotion(type, id, name, price);
        }
        JTablePromotion();
        LoadAllMenu();
        LoadAllStock();
        JtableCart();
        JOptionPane.showMessageDialog(this, "All promotion has been update",
                "Update Promotion.", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_DessertUpdateActionPerformed

    private void MaincourseUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MaincourseUpdateActionPerformed

        for (int i = 0; i < MaincoursePromotion.getRowCount(); i++) {
            String name = MaincoursePromotion.getValueAt(i, 0).toString();
            String id = MaincoursePromotion.getValueAt(i, 1).toString();
            String price = MaincoursePromotion.getValueAt(i, 2).toString();
            String type = MaincoursePromotion.getValueAt(i, 3).toString();
            UpdatepPromotion(type, id, name, price);
        }
        JTablePromotion();
        LoadAllMenu();
        LoadAllStock();
        JtableCart();
        JOptionPane.showMessageDialog(this, "All promotion has been update",
                "Update Promotion.", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_MaincourseUpdateActionPerformed

    private void DrinksUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DrinksUpdateActionPerformed

        for (int i = 0; i < DrinksPromotion.getRowCount(); i++) {
            String name = DrinksPromotion.getValueAt(i, 0).toString();
            String id = DrinksPromotion.getValueAt(i, 1).toString();
            String price = DrinksPromotion.getValueAt(i, 2).toString();
            String type = DrinksPromotion.getValueAt(i, 3).toString();
            UpdatepPromotion(type, id, name, price);
        }
        JTablePromotion();
        LoadAllMenu();
        LoadAllStock();
        JtableCart();
        JOptionPane.showMessageDialog(this, "All promotion has been update",
                "Update Promotion.", JOptionPane.INFORMATION_MESSAGE);

    }//GEN-LAST:event_DrinksUpdateActionPerformed

    private void NextTobillActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextTobillActionPerformed
        try {
         AddQueueTobill();   
          SaveBillFile();
          String billData = setBill();
          GuiBill bill = new GuiBill(billData);
             bill.setVisible(true);
              clearTable(CartTable);
              shop.Clearcart();
         Totalprice.setText("0.0");
        paymoney.setText("0,0");
        Changeforcustomer.setText("0.0");
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        
    }//GEN-LAST:event_NextTobillActionPerformed

    private void ClearCartBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearCartBTNActionPerformed
        int confirmation = JOptionPane.showConfirmDialog(
                this,
                "Are you sure to Clear all order?",
                "Confirm clearing all order",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
        if (confirmation == JOptionPane.YES_OPTION) {
            ClearCart();
            JOptionPane.showMessageDialog(this,
                    "All queue has been cleared.",
                    "Successful.",
                    JOptionPane.INFORMATION_MESSAGE);
        }


    }//GEN-LAST:event_ClearCartBTNActionPerformed
    
    //NEW method from trinn
    private void DeleteCartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteCartButtonActionPerformed
        // TODO add your handling code here:
        int selectedRow = CartTable.getSelectedRow();
        if (selectedRow >= 0) {
            namefordeletecart = CartTable.getValueAt(selectedRow, 0).toString();
            commentfordeletecart = CartTable.getValueAt(selectedRow, 4).toString();
            try {
                DeleteCart(namefordeletecart, commentfordeletecart);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }//GEN-LAST:event_DeleteCartButtonActionPerformed

    
    private void CartTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CartTableMouseClicked
        // TODO add your handling code here:
        int selectedRow = CartTable.getSelectedRow();
        if (selectedRow >= 0) {
            String nameforfixcart = CartTable.getValueAt(selectedRow, 0).toString();
            String commentforfixcart = CartTable.getValueAt(selectedRow, 4).toString();
            String quantityforfixcart = CartTable.getValueAt(selectedRow, 2).toString();
            int quantity = Integer.parseInt(quantityforfixcart);
            changequantityandcomment(nameforfixcart, quantity, commentforfixcart);
        }


    }//GEN-LAST:event_CartTableMouseClicked

    private void DessertUpdateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DessertUpdateMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_DessertUpdateMouseClicked

    private void paybuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paybuttonActionPerformed
        Setchange();
    }//GEN-LAST:event_paybuttonActionPerformed

    private void NextQueueBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NextQueueBTNActionPerformed
       
        try {
            shop.Deletequeue(1);
            LoadQueueData(); 
            JOptionPane.showMessageDialog(this, "Next queue update successfully!");
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Don't have queue " + e.getMessage());
        }
    }//GEN-LAST:event_NextQueueBTNActionPerformed

    private void DeleteQueueBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteQueueBTNActionPerformed
       int selectedRow = QueueTable.getSelectedRow();
        Deletequeue(selectedRow);
    }//GEN-LAST:event_DeleteQueueBTNActionPerformed

    private void ClearQueueBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearQueueBTNActionPerformed
       ClearQueue();
    }//GEN-LAST:event_ClearQueueBTNActionPerformed
     
   
    
    
    //NEW method from trinn 
    private boolean isCreateMenuSelected = false;
    private boolean isDrinkMenuSelected = false;
    private boolean isDessertMenuSelected = false;
    private boolean isMainMenuSelected = false;
    private boolean isDrinkStockSelected = false;
    private boolean isDessertStockSelected = false;
    private boolean isMainStockSelected = false;
    private boolean isPromotionSelected = false;

    private void resetAllButton() {
        isCreateMenuSelected = false;
        isDrinkMenuSelected = false;
        isDessertMenuSelected = false;
        isMainMenuSelected = false;
        isDrinkStockSelected = false;
        isDessertStockSelected = false;
        isMainStockSelected = false;
        isPromotionSelected = false;
        
        CreateMenubtn.setBackground(Color.WHITE);
        Drinkmenubtn.setBackground(Color.WHITE);
        Dessertmenubtn.setBackground(Color.WHITE);
        Maincoursemenubtn.setBackground(Color.WHITE);
        Drinkstockbtn.setBackground(Color.WHITE);
        Dessertstockbtn.setBackground(Color.WHITE);
        Maincoursestockbtn.setBackground(Color.WHITE);
        Promotionbtn.setBackground(Color.WHITE);
    }
    private void CreateMenubtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CreateMenubtnMouseEntered
        CreateMenubtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_CreateMenubtnMouseEntered

    private void CreateMenubtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CreateMenubtnMouseExited
        if (!isCreateMenuSelected) {
            CreateMenubtn.setBackground(Color.WHITE);
        }
    }//GEN-LAST:event_CreateMenubtnMouseExited

    private void DrinkmenubtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DrinkmenubtnMouseEntered

        Drinkmenubtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_DrinkmenubtnMouseEntered

    private void DrinkmenubtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DrinkmenubtnMouseExited
        if (!isDrinkMenuSelected) {
            Drinkmenubtn.setBackground(Color.WHITE);
        }
    }//GEN-LAST:event_DrinkmenubtnMouseExited

    private void MaincoursemenubtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MaincoursemenubtnMouseEntered
        Maincoursemenubtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_MaincoursemenubtnMouseEntered

    private void MaincoursemenubtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MaincoursemenubtnMouseExited
        if (!isMainMenuSelected) {
            Maincoursemenubtn.setBackground(Color.WHITE);
        }
    }//GEN-LAST:event_MaincoursemenubtnMouseExited

    private void DessertmenubtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DessertmenubtnMouseEntered
        Dessertmenubtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_DessertmenubtnMouseEntered

    private void DessertmenubtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DessertmenubtnMouseExited
        if (!isDessertMenuSelected) {
            Dessertmenubtn.setBackground(Color.WHITE);
        }
    }//GEN-LAST:event_DessertmenubtnMouseExited

    private void DrinkstockbtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DrinkstockbtnMouseEntered
        Drinkstockbtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_DrinkstockbtnMouseEntered

    private void DrinkstockbtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DrinkstockbtnMouseExited
        if (!isDrinkStockSelected) {
            Drinkstockbtn.setBackground(Color.WHITE);
        }
    }//GEN-LAST:event_DrinkstockbtnMouseExited

    private void MaincoursestockbtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MaincoursestockbtnMouseEntered
        Maincoursestockbtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_MaincoursestockbtnMouseEntered

    private void MaincoursestockbtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MaincoursestockbtnMouseExited
        if (!isMainStockSelected) {
            Maincoursestockbtn.setBackground(Color.WHITE);
        }
    }//GEN-LAST:event_MaincoursestockbtnMouseExited

    private void DessertstockbtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DessertstockbtnMouseEntered
        Dessertstockbtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_DessertstockbtnMouseEntered

    private void DessertstockbtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DessertstockbtnMouseExited
        if (!isDessertStockSelected) {
            Dessertstockbtn.setBackground(Color.WHITE);
        }
    }//GEN-LAST:event_DessertstockbtnMouseExited

    private void PromotionbtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PromotionbtnMouseEntered
        Promotionbtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_PromotionbtnMouseEntered

    private void PromotionbtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PromotionbtnMouseExited
        if (!isPromotionSelected) {
            Promotionbtn.setBackground(Color.WHITE);
        }
    }//GEN-LAST:event_PromotionbtnMouseExited

    private void CreateMenubtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CreateMenubtnMouseClicked
        resetAllButton();
        isCreateMenuSelected = true;
        CreateMenubtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_CreateMenubtnMouseClicked

    private void DrinkmenubtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DrinkmenubtnMouseClicked
        resetAllButton();
        isDrinkMenuSelected = true;
        Drinkmenubtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_DrinkmenubtnMouseClicked

    private void MaincoursemenubtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MaincoursemenubtnMouseClicked
        resetAllButton();
        isMainMenuSelected = true;
        Maincoursemenubtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_MaincoursemenubtnMouseClicked

    private void DessertmenubtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DessertmenubtnMouseClicked
        resetAllButton();
        isDessertMenuSelected = true;
        Dessertmenubtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_DessertmenubtnMouseClicked

    private void DrinkstockbtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DrinkstockbtnMouseClicked
        resetAllButton();
        isDrinkStockSelected = true;
        Drinkstockbtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_DrinkstockbtnMouseClicked

    private void MaincoursestockbtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MaincoursestockbtnMouseClicked
        resetAllButton();
        isMainStockSelected = true;
        Maincoursestockbtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_MaincoursestockbtnMouseClicked

    private void DessertstockbtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DessertstockbtnMouseClicked
        resetAllButton();
        isDessertStockSelected = true;
        Dessertstockbtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_DessertstockbtnMouseClicked

    private void PromotionbtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PromotionbtnMouseClicked
        resetAllButton();
        isPromotionSelected = true;
        Promotionbtn.setBackground(new Color(255, 204, 204));
    }//GEN-LAST:event_PromotionbtnMouseClicked

    private void AddphotobuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddphotobuttonActionPerformed
        JFileChooser choose = new JFileChooser();
        int Checkchoose = choose.showOpenDialog(this);
        if (Checkchoose == JFileChooser.APPROVE_OPTION) {
            File file = choose.getSelectedFile();
            String path = file.getAbsolutePath().replace("\\", "/");
            Textnamephoto.setText(path);
        }
    }//GEN-LAST:event_AddphotobuttonActionPerformed

    private void AddMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddMenuButtonActionPerformed
        String Selecttype = (String) SelectTypefood.getSelectedItem();
        String name = TextNamefood.getText();
        String Id = TextID.getText();
        String price = TextPrice.getText();
        String photo = Textnamephoto.getText();

        if (Selecttype == null || Selecttype.isEmpty() || name.isEmpty() || Id.isEmpty() || price.isEmpty() || photo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields.",
                "Invalid Information", JOptionPane.WARNING_MESSAGE);
            return;
        }
        double Setprice;
        try {
            Setprice = Double.parseDouble(price);
            if (Setprice < 0) {
                JOptionPane.showMessageDialog(this, "Price must be a non-negative number.",
                    "Invalid Price", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number.",
                "Invalid Price", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            shop.Createmenu(Selecttype, Id, name, Setprice, Textnamephoto.getText());
            LoadAllMenu();
            SelectTypefood.setSelectedItem(null);
            TextID.setText("");
            TextPrice.setText("");
            TextNamefood.setText("");
            Textnamephoto.setText("");

            JOptionPane.showMessageDialog(this, "Menu " + name + " has been successfully added to Menu.",
                "Menu added successfully.", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                "Error " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_AddMenuButtonActionPerformed

    private void TextIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextIDActionPerformed

    private void paymoneyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paymoneyActionPerformed
        // TODO add your handling code here:
         
    }//GEN-LAST:event_paymoneyActionPerformed

    private void paymoneyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paymoneyMouseClicked
        // TODO add your handling code here:
      
    }//GEN-LAST:event_paymoneyMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GuiRestaurant().setVisible(true));
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddMenuButton;
    private javax.swing.JButton Addphotobutton;
    private javax.swing.JPanel Allpage;
    private javax.swing.JButton CartButton;
    private javax.swing.JPanel CartPage;
    private javax.swing.JTable CartTable;
    private javax.swing.JTextField Changeforcustomer;
    private javax.swing.JButton ClearCartBTN;
    private java.awt.Button ClearQueueBTN;
    private javax.swing.JPanel CreateMenu;
    private javax.swing.JButton CreateMenubtn;
    private javax.swing.JScrollPane DRMscroll;
    private javax.swing.JScrollPane DRTscroll;
    private javax.swing.JScrollPane DSMscroll;
    private javax.swing.JScrollPane DSTscroll;
    private javax.swing.JButton DeleteCartButton;
    private javax.swing.JPanel DeletePanel;
    private java.awt.Button DeleteQueueBTN;
    private java.awt.Button DessertButton;
    private javax.swing.JPanel DessertMenu;
    private javax.swing.JPanel DessertPage;
    private javax.swing.JPanel DessertStock;
    private javax.swing.JButton DessertUpdate;
    private javax.swing.JButton Dessertmenubtn;
    private javax.swing.JButton Dessertstockbtn;
    private javax.swing.JButton Drinkmenubtn;
    private java.awt.Button DrinksButton;
    private javax.swing.JPanel DrinksMenu;
    private javax.swing.JPanel DrinksPage;
    private javax.swing.JPanel DrinksStock;
    private javax.swing.JButton DrinksUpdate;
    private javax.swing.JButton Drinkstockbtn;
    private javax.swing.JButton ExitGui1;
    private javax.swing.JPanel GoodsDessert;
    private javax.swing.JPanel GoodsDrinks;
    private javax.swing.JPanel GoodsMaincourse;
    private javax.swing.JScrollPane MCMscroll;
    private javax.swing.JScrollPane MCTscroll;
    private java.awt.Button MaincourseButton;
    private javax.swing.JPanel MaincourseMenu;
    private javax.swing.JPanel MaincoursePage;
    private javax.swing.JPanel MaincourseStock;
    private javax.swing.JButton MaincourseUpdate;
    private javax.swing.JButton Maincoursemenubtn;
    private javax.swing.JButton Maincoursestockbtn;
    private javax.swing.JPanel ManageMenuPage;
    private javax.swing.JPanel ManagePage;
    private javax.swing.JPanel ManagePageSetting;
    private javax.swing.JPanel ManagePromotion;
    private javax.swing.JPanel ManagePromotionPage;
    private java.awt.Button NextQueueBTN;
    private javax.swing.JButton NextTobill;
    private javax.swing.JPanel PageforDelete;
    private javax.swing.JPanel PageforDessertMenu;
    private javax.swing.JPanel PageforDessertStock;
    private javax.swing.JPanel PageforDrinksMenu;
    private javax.swing.JPanel PageforDrinksStock;
    private javax.swing.JPanel PageforMaincourseMenu;
    private javax.swing.JPanel PageforMaincourseStock;
    private javax.swing.JPanel PromotionDessert;
    private javax.swing.JPanel PromotionDrinks;
    private javax.swing.JPanel PromotionMaincourse;
    private javax.swing.JButton Promotionbtn;
    private java.awt.Button QueueButton;
    private javax.swing.JPanel QueuePage;
    private javax.swing.JTable QueueTable;
    private javax.swing.JComboBox<String> SelectTypefood;
    private javax.swing.JTable TableDessert;
    private javax.swing.JTable TableDrinks;
    private javax.swing.JTable TableMaincourse;
    private javax.swing.JTextField TextID;
    private javax.swing.JTextField TextNamefood;
    private javax.swing.JTextField TextPrice;
    private javax.swing.JTextField Textnamephoto;
    private javax.swing.JTextField Totalprice;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel100;
    private javax.swing.JPanel jPanel101;
    private javax.swing.JPanel jPanel102;
    private javax.swing.JPanel jPanel103;
    private javax.swing.JPanel jPanel104;
    private javax.swing.JPanel jPanel105;
    private javax.swing.JPanel jPanel106;
    private javax.swing.JPanel jPanel107;
    private javax.swing.JPanel jPanel108;
    private javax.swing.JPanel jPanel109;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel110;
    private javax.swing.JPanel jPanel111;
    private javax.swing.JPanel jPanel112;
    private javax.swing.JPanel jPanel113;
    private javax.swing.JPanel jPanel114;
    private javax.swing.JPanel jPanel115;
    private javax.swing.JPanel jPanel116;
    private javax.swing.JPanel jPanel117;
    private javax.swing.JPanel jPanel118;
    private javax.swing.JPanel jPanel119;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel120;
    private javax.swing.JPanel jPanel121;
    private javax.swing.JPanel jPanel122;
    private javax.swing.JPanel jPanel123;
    private javax.swing.JPanel jPanel124;
    private javax.swing.JPanel jPanel125;
    private javax.swing.JPanel jPanel126;
    private javax.swing.JPanel jPanel127;
    private javax.swing.JPanel jPanel128;
    private javax.swing.JPanel jPanel129;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel130;
    private javax.swing.JPanel jPanel131;
    private javax.swing.JPanel jPanel132;
    private javax.swing.JPanel jPanel133;
    private javax.swing.JPanel jPanel134;
    private javax.swing.JPanel jPanel135;
    private javax.swing.JPanel jPanel136;
    private javax.swing.JPanel jPanel137;
    private javax.swing.JPanel jPanel138;
    private javax.swing.JPanel jPanel139;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel140;
    private javax.swing.JPanel jPanel141;
    private javax.swing.JPanel jPanel142;
    private javax.swing.JPanel jPanel143;
    private javax.swing.JPanel jPanel144;
    private javax.swing.JPanel jPanel145;
    private javax.swing.JPanel jPanel146;
    private javax.swing.JPanel jPanel147;
    private javax.swing.JPanel jPanel148;
    private javax.swing.JPanel jPanel149;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel150;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel62;
    private javax.swing.JPanel jPanel63;
    private javax.swing.JPanel jPanel64;
    private javax.swing.JPanel jPanel65;
    private javax.swing.JPanel jPanel66;
    private javax.swing.JPanel jPanel67;
    private javax.swing.JPanel jPanel68;
    private javax.swing.JPanel jPanel69;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel70;
    private javax.swing.JPanel jPanel71;
    private javax.swing.JPanel jPanel72;
    private javax.swing.JPanel jPanel73;
    private javax.swing.JPanel jPanel74;
    private javax.swing.JPanel jPanel75;
    private javax.swing.JPanel jPanel76;
    private javax.swing.JPanel jPanel77;
    private javax.swing.JPanel jPanel78;
    private javax.swing.JPanel jPanel79;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel80;
    private javax.swing.JPanel jPanel81;
    private javax.swing.JPanel jPanel82;
    private javax.swing.JPanel jPanel83;
    private javax.swing.JPanel jPanel84;
    private javax.swing.JPanel jPanel85;
    private javax.swing.JPanel jPanel86;
    private javax.swing.JPanel jPanel87;
    private javax.swing.JPanel jPanel88;
    private javax.swing.JPanel jPanel89;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel90;
    private javax.swing.JPanel jPanel91;
    private javax.swing.JPanel jPanel92;
    private javax.swing.JPanel jPanel93;
    private javax.swing.JPanel jPanel94;
    private javax.swing.JPanel jPanel95;
    private javax.swing.JPanel jPanel96;
    private javax.swing.JPanel jPanel97;
    private javax.swing.JPanel jPanel98;
    private javax.swing.JPanel jPanel99;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private javax.swing.JButton paybutton;
    private javax.swing.JTextField paymoney;
    // End of variables declaration//GEN-END:variables

}
