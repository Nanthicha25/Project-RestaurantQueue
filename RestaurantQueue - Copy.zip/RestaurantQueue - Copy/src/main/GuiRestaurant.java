
package main;

import Menu.*;
import Stock.*;
import javax.swing.*;
import  java.io.*;
import java.util.List;
import lib.*;


/**
 *
 * @author nanth
 */
public class GuiRestaurant extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GuiRestaurant.class.getName());
  private String namestock[]={"DrinksStock","DessertStock","MaincourseStock"};
  private  shopcenter shop;
 private GuiforMenu Showguimenu=new GuiforMenu(this);
 private  GuiAddStock guiaddstock=new GuiAddStock(this);
 private String s;
private String namemenu[]={"Drinks","Maincourse","Dessert"};

    /**
     * Creates new form GuiRestaurant
     */
    public GuiRestaurant() {
        initComponents();
      shop=new shopcenter();
      Drinks Drinks=new Drinks();
Dessert Dessert=new Dessert();
Maincourse Maincourse=new Maincourse();
 shop.SetTypetoMenu("Drinks", Drinks);
shop.SetTypetoMenu("Maincourse", Maincourse);
shop.SetTypetoMenu("Dessert", Dessert);
        Managebutton();
        LoadAllMenu();
        LoadAllStock();
        setVisible(true);
        setResizable(false);
        setLocationRelativeTo(null); 
        setExtendedState(GuiRestaurant.MAXIMIZED_BOTH); //fullscreen every  run
         DessertStock dessertStock=new DessertStock();
DrinksStock drinksStock=new DrinksStock();
MaincourseStock maincourseStock=new MaincourseStock();
shop.SetTypetoStock("Dessert",dessertStock);
shop.SetTypetoStock("Drinks",drinksStock);
shop.SetTypetoStock("Maincourse",maincourseStock);
 
            
    }
    
     private void LoadAllMenu() {

    for(String filemenu : namemenu) {
         try (
            
            FileReader fr = new FileReader(new File(filemenu));
            BufferedReader ReadMenu = new BufferedReader(fr);)
         {
        
            while((s = ReadMenu.readLine()) != null) {
                String text[] = s.split(",");
                GuiforMenu menu=new GuiforMenu(this);
                if(text.length > 4) { 
                    String name = text[0];
                    String Id = text[1];
                    String price = text[2];
                    String typefood=text[3];
                    String path = text[4]; // ใช้ Index 4
                    
                    menu.setData(Id, name, price,typefood);
                    menu.setPhoto(path);
                    if(typefood.equals("Drinks"))
                    { PageforDrinksMenu.add(menu.getMenuPanel());
                    PageforDrinksMenu.revalidate();
                    PageforDrinksMenu.repaint(); }
                     if(text[3].equals("Dessert"))
                    { PageforDessertMenu.add(menu.getMenuPanel());
                    PageforDessertMenu.revalidate();
                    PageforDessertMenu.repaint(); }
                      if(text[3].equals("Maincourse"))
                    { PageforMaincourseMenu.add(menu.getMenuPanel());
                    PageforMaincourseMenu.revalidate();
                    PageforMaincourseMenu.repaint(); }
                }
            }
          } catch (Exception e) {     
            System.out.println(e.getMessage());
        }}}

    private void LoadAllStock() {

    for(String filestock : namestock) {
         try (
            
            
            FileReader fr = new FileReader(new File(filestock));
            BufferedReader ReadMenu = new BufferedReader(fr);)
         {
        
            while((s = ReadMenu.readLine()) != null) {
                String text[] = s.split(",");
                GuiforStock stock=new GuiforStock();
                GuiforGoods goods=new GuiforGoods();
                if(text.length > 4) { 
                    String name = text[0];
                    String Id = text[1];
                    String price = text[2];
                    String typefood=text[3];
                    String path = text[4]; // ใช้ Index 4
                    
                    stock.setData( name, price);
                    stock.setPhoto(path);
                    goods.setData( name, price);
                    goods.setPhoto(path);
                    if(typefood.equals("Drinks"))
                    { PageforDrinksStock.add(stock.getStockPanel());
                    PageforDrinksStock.revalidate();
                    PageforDrinksStock.repaint();
                    GoodsDrinks.add(goods.getGoodsPanel());
                    GoodsDrinks.revalidate();
                    GoodsDrinks.repaint();}
                     if(text[3].equals("Dessert"))
                    { PageforDessertStock.add(stock.getStockPanel());
                    PageforDessertStock.revalidate();
                    PageforDessertStock.repaint();
                    GoodsDessert.add(goods.getGoodsPanel());
                     GoodsDessert.revalidate();
                     GoodsDessert.repaint(); }
                      if(text[3].equals("Maincourse"))
                    { PageforMaincourseStock.add(stock.getStockPanel());
                   PageforMaincourseStock.revalidate();
                    PageforMaincourseStock.repaint(); 
                    GoodsMaincourse.add(goods.getGoodsPanel());
                   GoodsMaincourse.revalidate();
                   GoodsMaincourse.repaint();}
                }
            }
          } catch (Exception e) {     
            System.out.println(e.getMessage());
        }}}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // </editor-fold>


    private void Managebutton()
    {    SelectTypefood.removeAllItems();
        SelectTypefood.addItem("Drinks");
        SelectTypefood.addItem("Maincourse");
        SelectTypefood.addItem("Dessert");
        SelectTypefood.setSelectedItem(null);
        
       
    }
    public void ManagebuttonforAddStock(GuiforMenu ShowguiMenu)
     {    String price=ShowguiMenu.getTextPrice();
        String typefood = ShowguiMenu.getTextType();
    String Id = ShowguiMenu.getTextId();
    String Name = ShowguiMenu.getTextName();
     try {
        List<String> CheckStock=shop.findstockbyName(Name);  
        
        if(CheckStock.isEmpty()){
            shop.Addstock(typefood,Id,Name);
            List<String> DatafromMenu=shop.findstockbyName(Name);
 
            String text[]=DatafromMenu.get(0).split(",");
            GuiforStock guistock=new GuiforStock();
            GuiforGoods goods=new GuiforGoods();
            
            if(text.length>4)
            {guistock.setData(Name, price);
            guistock.setPhoto(text[4]);
            goods.setData(Name, price);
            goods.setPhoto(text[4]);
            
            
            if(typefood.equals("Drinks"))
            { 
                PageforDrinksStock.add(guistock.getStockPanel());
                GoodsDrinks.add(goods.getGoodsPanel());
                
                
                PageforDrinksStock.revalidate();
                PageforDrinksStock.repaint();
                GoodsDrinks.revalidate();
                GoodsDrinks.repaint();
            }
            else if(typefood.equals("Dessert"))
            {
                PageforDessertStock.add(guistock.getStockPanel());
                GoodsDessert.add(goods.getGoodsPanel());
               
                PageforDessertStock.revalidate();
                PageforDessertStock.repaint();
                GoodsDessert.revalidate();
                GoodsDessert.repaint();
            }
            else if(typefood.equals("Maincourse"))
            { 
                PageforMaincourseStock.add(guistock.getStockPanel());
                GoodsMaincourse.add(goods.getGoodsPanel());
                
               
                PageforMaincourseStock.revalidate();
                PageforMaincourseStock.repaint();
                GoodsMaincourse.revalidate();
                GoodsMaincourse.repaint();
            }}}
            
            
            this.revalidate();
            this.repaint();        
     } catch (Exception e) {
            System.out.println(e.getMessage()); }}

       
   
    
   
    
    public void switchPanel(JPanel newPanel) {
    getContentPane().removeAll();   
    getContentPane().add(newPanel); 
    revalidate();                   
    repaint();                      
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
   
   @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jButton1 = new javax.swing.JButton();
        jPanel19 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jPanel25 = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        Allpage = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        QueueButton = new java.awt.Button();
        DrinksButton = new java.awt.Button();
        MaincourseButton = new java.awt.Button();
        DessertButton = new java.awt.Button();
        jPanel21 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        CartButton = new javax.swing.JButton();
        jPanel23 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        ExitGui1 = new javax.swing.JButton();
        jPanel26 = new javax.swing.JPanel();
        label1 = new java.awt.Label();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        ManagePage = new javax.swing.JPanel();
        QueuePage = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        button5 = new java.awt.Button();
        button6 = new java.awt.Button();
        button7 = new java.awt.Button();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        DrinksPage = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        GoodsDrinks = new javax.swing.JPanel();
        MaincoursePage = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        GoodsMaincourse = new javax.swing.JPanel();
        DessertPage = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        GoodsDessert = new javax.swing.JPanel();
        CartPage = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel29 = new javax.swing.JPanel();
        label2 = new java.awt.Label();
        jButton2 = new javax.swing.JButton();
        jPanel31 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        jPanel37 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel38 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel39 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        ManagePageSetting = new javax.swing.JPanel();
        CreateMenu = new javax.swing.JPanel();
        jPanel40 = new javax.swing.JPanel();
        jPanel41 = new javax.swing.JPanel();
        jPanel42 = new javax.swing.JPanel();
        jPanel43 = new javax.swing.JPanel();
        jPanel44 = new javax.swing.JPanel();
        jPanel45 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel46 = new javax.swing.JPanel();
        TextNamefood = new javax.swing.JTextField();
        SelectTypefood = new javax.swing.JComboBox<>();
        Textnamephoto = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        AddMenuButton = new javax.swing.JButton();
        TextID = new javax.swing.JTextField();
        Addphotobutton = new javax.swing.JButton();
        TextPrice = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        DrinksMenu = new javax.swing.JPanel();
        jPanel47 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        PageforDrinksMenu = new javax.swing.JPanel();
        MaincourseMenu = new javax.swing.JPanel();
        jPanel48 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jPanel49 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        PageforMaincourseMenu = new javax.swing.JPanel();
        DessertMenu = new javax.swing.JPanel();
        jPanel50 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jPanel51 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        PageforDessertMenu = new javax.swing.JPanel();
        DrinksStock = new javax.swing.JPanel();
        jPanel52 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jPanel53 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        PageforDrinksStock = new javax.swing.JPanel();
        MaincourseStock = new javax.swing.JPanel();
        jPanel54 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel55 = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        PageforMaincourseStock = new javax.swing.JPanel();
        DessertStock = new javax.swing.JPanel();
        jPanel56 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel57 = new javax.swing.JPanel();
        jScrollPane11 = new javax.swing.JScrollPane();
        PageforDessertStock = new javax.swing.JPanel();
        ManagePromotion = new javax.swing.JPanel();
        jPanel58 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jPanel59 = new javax.swing.JPanel();
        jPanel60 = new javax.swing.JPanel();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jPanel61 = new javax.swing.JPanel();

        jButton1.setText("jButton1");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel4.setText("Drinks");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 0));
        setPreferredSize(new java.awt.Dimension(800, 600));

        Allpage.setPreferredSize(new java.awt.Dimension(827, 164));
        Allpage.setLayout(new java.awt.CardLayout());

        jPanel30.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));
        jPanel2.setAlignmentY(0.0F);
        jPanel2.setPreferredSize(new java.awt.Dimension(400, 160));
        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel6.setBackground(new java.awt.Color(255, 255, 204));
        jPanel6.setAlignmentX(0.0F);
        jPanel6.setAlignmentY(0.0F);
        jPanel6.setMinimumSize(new java.awt.Dimension(375, 30));
        jPanel6.setPreferredSize(new java.awt.Dimension(100, 40));
        java.awt.GridBagLayout jPanel6Layout = new java.awt.GridBagLayout();
        jPanel6Layout.rowHeights = new int[] {50};
        jPanel6.setLayout(jPanel6Layout);

        QueueButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        QueueButton.setLabel("Queue");
        QueueButton.setName(""); // NOI18N
        QueueButton.setPreferredSize(new java.awt.Dimension(50, 25));
        QueueButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                QueueButtonMouseClicked(evt);
            }
        });
        QueueButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QueueButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 80;
        gridBagConstraints.ipady = 20;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 90, 30, 0);
        jPanel6.add(QueueButton, gridBagConstraints);

        DrinksButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        DrinksButton.setLabel("Drinks");
        DrinksButton.setPreferredSize(new java.awt.Dimension(50, 25));
        DrinksButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DrinksButtonMouseClicked(evt);
            }
        });
        DrinksButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DrinksButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 80;
        gridBagConstraints.ipady = 20;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 100, 30, 20);
        jPanel6.add(DrinksButton, gridBagConstraints);

        MaincourseButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        MaincourseButton.setLabel("Maincourse");
        MaincourseButton.setPreferredSize(new java.awt.Dimension(50, 25));
        MaincourseButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MaincourseButtonMouseClicked(evt);
            }
        });
        MaincourseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MaincourseButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 80;
        gridBagConstraints.ipady = 20;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 60, 30, 70);
        jPanel6.add(MaincourseButton, gridBagConstraints);

        DessertButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        DessertButton.setLabel("Dessert");
        DessertButton.setPreferredSize(new java.awt.Dimension(50, 35));
        DessertButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DessertButtonMouseClicked(evt);
            }
        });
        DessertButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DessertButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = java.awt.GridBagConstraints.RELATIVE;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 80;
        gridBagConstraints.ipady = 20;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 30, 95);
        jPanel6.add(DessertButton, gridBagConstraints);

        jPanel2.add(jPanel6, java.awt.BorderLayout.CENTER);

        jPanel21.setBackground(new java.awt.Color(204, 255, 204));
        jPanel21.setPreferredSize(new java.awt.Dimension(100, 30));
        jPanel2.add(jPanel21, java.awt.BorderLayout.PAGE_END);

        jPanel18.setPreferredSize(new java.awt.Dimension(100, 80));
        jPanel18.setLayout(new java.awt.BorderLayout());

        jPanel22.setBackground(new java.awt.Color(255, 255, 204));
        jPanel22.setPreferredSize(new java.awt.Dimension(70, 40));

        CartButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-cart.gif"))); // NOI18N
        CartButton.setBorderPainted(false);
        CartButton.setContentAreaFilled(false);
        CartButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CartButtonMouseClicked(evt);
            }
        });
        CartButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CartButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
        jPanel22.setLayout(jPanel22Layout);
        jPanel22Layout.setHorizontalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel22Layout.createSequentialGroup()
                .addComponent(CartButton, javax.swing.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel22Layout.setVerticalGroup(
            jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel22Layout.createSequentialGroup()
                .addComponent(CartButton, javax.swing.GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel18.add(jPanel22, java.awt.BorderLayout.LINE_END);

        jPanel23.setBackground(new java.awt.Color(255, 255, 204));
        jPanel23.setForeground(new java.awt.Color(255, 255, 204));
        jPanel23.setPreferredSize(new java.awt.Dimension(140, 40));
        jPanel23.setLayout(null);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-restaurant-40.png"))); // NOI18N
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel23.add(jButton3);
        jButton3.setBounds(10, 10, 50, 51);

        ExitGui1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-close-sign-40.png"))); // NOI18N
        ExitGui1.setAlignmentY(0.0F);
        ExitGui1.setBorderPainted(false);
        ExitGui1.setContentAreaFilled(false);
        ExitGui1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitGui1ActionPerformed(evt);
            }
        });
        jPanel23.add(ExitGui1);
        ExitGui1.setBounds(60, 10, 50, 51);

        jPanel18.add(jPanel23, java.awt.BorderLayout.LINE_START);

        jPanel26.setBackground(new java.awt.Color(255, 255, 204));

        label1.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        label1.setText("Menu");
        jPanel26.add(label1);

        jPanel18.add(jPanel26, java.awt.BorderLayout.CENTER);

        jPanel2.add(jPanel18, java.awt.BorderLayout.PAGE_START);

        jPanel30.add(jPanel2, java.awt.BorderLayout.PAGE_START);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setPreferredSize(new java.awt.Dimension(40, 100));
        jPanel30.add(jPanel1, java.awt.BorderLayout.LINE_START);

        jPanel3.setBackground(new java.awt.Color(204, 255, 204));
        jPanel3.setForeground(new java.awt.Color(255, 255, 204));
        jPanel3.setPreferredSize(new java.awt.Dimension(40, 100));
        jPanel30.add(jPanel3, java.awt.BorderLayout.LINE_END);

        jPanel4.setBackground(new java.awt.Color(204, 255, 204));
        jPanel4.setPreferredSize(new java.awt.Dimension(100, 60));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 872, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        jPanel30.add(jPanel4, java.awt.BorderLayout.PAGE_END);

        ManagePage.setLayout(new java.awt.CardLayout());

        QueuePage.setLayout(new java.awt.BorderLayout());

        jPanel11.setBackground(new java.awt.Color(255, 204, 204));
        jPanel11.setPreferredSize(new java.awt.Dimension(100, 50));
        jPanel11.setLayout(new java.awt.GridBagLayout());

        button5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        button5.setLabel("Next Queue");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 1;
        gridBagConstraints.ipady = 10;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(0, 200, 0, 130);
        jPanel11.add(button5, gridBagConstraints);

        button6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        button6.setLabel("Delete");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 1;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 130);
        jPanel11.add(button6, gridBagConstraints);

        button7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        button7.setLabel("Clear");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 1;
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 200);
        jPanel11.add(button7, gridBagConstraints);

        QueuePage.add(jPanel11, java.awt.BorderLayout.PAGE_END);

        jPanel12.setPreferredSize(new java.awt.Dimension(30, 100));
        QueuePage.add(jPanel12, java.awt.BorderLayout.LINE_START);

        jPanel13.setPreferredSize(new java.awt.Dimension(30, 100));
        QueuePage.add(jPanel13, java.awt.BorderLayout.LINE_END);

        jPanel14.setPreferredSize(new java.awt.Dimension(100, 30));
        QueuePage.add(jPanel14, java.awt.BorderLayout.PAGE_START);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        QueuePage.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        ManagePage.add(QueuePage, "card2");

        DrinksPage.setBackground(new java.awt.Color(255, 255, 255));
        DrinksPage.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(255, 204, 255));
        jPanel5.setForeground(new java.awt.Color(0, 0, 0));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Drinks");
        jPanel5.add(jLabel5);

        DrinksPage.add(jPanel5, java.awt.BorderLayout.PAGE_START);

        jScrollPane3.setBackground(new java.awt.Color(255, 255, 255));

        GoodsDrinks.setBackground(new java.awt.Color(255, 255, 255));
        GoodsDrinks.setLayout(new java.awt.GridLayout(0, 4));
        jScrollPane3.setViewportView(GoodsDrinks);

        DrinksPage.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        ManagePage.add(DrinksPage, "card3");

        MaincoursePage.setBackground(new java.awt.Color(255, 255, 255));
        MaincoursePage.setLayout(new java.awt.BorderLayout());

        jPanel9.setBackground(new java.awt.Color(255, 204, 255));

        jLabel6.setBackground(new java.awt.Color(255, 255, 255));
        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Maincourse");
        jPanel9.add(jLabel6);

        MaincoursePage.add(jPanel9, java.awt.BorderLayout.PAGE_START);

        jScrollPane4.setBackground(new java.awt.Color(255, 255, 255));

        GoodsMaincourse.setBackground(new java.awt.Color(255, 255, 255));
        GoodsMaincourse.setLayout(new java.awt.GridLayout(0, 4));
        jScrollPane4.setViewportView(GoodsMaincourse);

        MaincoursePage.add(jScrollPane4, java.awt.BorderLayout.CENTER);

        ManagePage.add(MaincoursePage, "card4");

        DessertPage.setBackground(new java.awt.Color(255, 255, 255));
        DessertPage.setLayout(new java.awt.BorderLayout());

        jPanel28.setBackground(new java.awt.Color(255, 204, 255));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Dessert");
        jPanel28.add(jLabel7);

        DessertPage.add(jPanel28, java.awt.BorderLayout.PAGE_START);

        jScrollPane5.setBackground(new java.awt.Color(255, 255, 255));

        GoodsDessert.setBackground(new java.awt.Color(255, 255, 255));
        GoodsDessert.setLayout(new java.awt.GridLayout(0, 4));
        jScrollPane5.setViewportView(GoodsDessert);

        DessertPage.add(jScrollPane5, java.awt.BorderLayout.CENTER);

        ManagePage.add(DessertPage, "card5");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        label2.setBackground(new java.awt.Color(255, 255, 255));
        label2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        label2.setText("Cart");
        jPanel29.add(label2);

        jButton2.setText("next");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CartPageLayout = new javax.swing.GroupLayout(CartPage);
        CartPage.setLayout(CartPageLayout);
        CartPageLayout.setHorizontalGroup(
            CartPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel29, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CartPageLayout.createSequentialGroup()
                .addContainerGap(387, Short.MAX_VALUE)
                .addGroup(CartPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CartPageLayout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CartPageLayout.createSequentialGroup()
                        .addComponent(jButton2)
                        .addGap(51, 51, 51))))
        );
        CartPageLayout.setVerticalGroup(
            CartPageLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CartPageLayout.createSequentialGroup()
                .addComponent(jPanel29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        ManagePage.add(CartPage, "card6");

        jPanel30.add(ManagePage, java.awt.BorderLayout.CENTER);

        Allpage.add(jPanel30, "card2");

        jPanel31.setLayout(new java.awt.BorderLayout());

        jPanel32.setBackground(new java.awt.Color(255, 255, 255));
        jPanel32.setPreferredSize(new java.awt.Dimension(569, 70));
        jPanel32.setLayout(new java.awt.BorderLayout());

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-arrow-40.png"))); // NOI18N
        jButton4.setBorderPainted(false);
        jButton4.setContentAreaFilled(false);
        jButton4.setPreferredSize(new java.awt.Dimension(100, 47));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel32.add(jButton4, java.awt.BorderLayout.LINE_START);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\nanth\\Downloads\\cartoon-table-full-food-including-bowl-ice-cream-bowl-fruit_777271-9665.png")); // NOI18N
        jPanel32.add(jLabel1, java.awt.BorderLayout.CENTER);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/main/cartoon-table-full-food-including-bowl-ice-cream-bowl-fruit_777271-9665 (1).png"))); // NOI18N
        jPanel32.add(jLabel18, java.awt.BorderLayout.LINE_END);

        jPanel31.add(jPanel32, java.awt.BorderLayout.PAGE_START);

        jPanel33.setBackground(new java.awt.Color(255, 255, 255));
        jPanel33.setPreferredSize(new java.awt.Dimension(400, 367));
        jPanel33.setLayout(new java.awt.BorderLayout());

        jPanel34.setBackground(new java.awt.Color(255, 255, 255));
        jPanel34.setPreferredSize(new java.awt.Dimension(300, 371));
        jPanel34.setLayout(new java.awt.BorderLayout());

        jPanel35.setBackground(new java.awt.Color(255, 153, 153));
        jPanel35.setPreferredSize(new java.awt.Dimension(5, 435));

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 367, Short.MAX_VALUE)
        );

        jPanel34.add(jPanel35, java.awt.BorderLayout.LINE_END);

        jPanel36.setBackground(new java.awt.Color(255, 255, 255));
        jPanel36.setForeground(new java.awt.Color(255, 204, 255));

        jPanel37.setBackground(new java.awt.Color(255, 153, 153));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Manage Menu");

        javax.swing.GroupLayout jPanel37Layout = new javax.swing.GroupLayout(jPanel37);
        jPanel37.setLayout(jPanel37Layout);
        jPanel37Layout.setHorizontalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addComponent(jLabel2))
        );
        jPanel37Layout.setVerticalGroup(
            jPanel37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel37Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jLabel2))
        );

        jPanel38.setBackground(new java.awt.Color(255, 153, 153));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Manage Promotion");

        javax.swing.GroupLayout jPanel38Layout = new javax.swing.GroupLayout(jPanel38);
        jPanel38.setLayout(jPanel38Layout);
        jPanel38Layout.setHorizontalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jLabel3))
        );
        jPanel38Layout.setVerticalGroup(
            jPanel38Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel38Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jLabel3))
        );

        jPanel39.setBackground(new java.awt.Color(255, 153, 153));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Manage Stock");

        javax.swing.GroupLayout jPanel39Layout = new javax.swing.GroupLayout(jPanel39);
        jPanel39.setLayout(jPanel39Layout);
        jPanel39Layout.setHorizontalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel8))
        );
        jPanel39Layout.setVerticalGroup(
            jPanel39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel39Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jLabel8))
        );

        jButton5.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton5.setText("Create Menu");
        jButton5.setContentAreaFilled(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton6.setText("Drinks");
        jButton6.setContentAreaFilled(false);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton7.setText("Maincourse");
        jButton7.setContentAreaFilled(false);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton8.setText("Dessert");
        jButton8.setContentAreaFilled(false);
        jButton8.setPreferredSize(new java.awt.Dimension(95, 24));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton9.setText("Drinks ");
        jButton9.setContentAreaFilled(false);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton10.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton10.setText("Maincourse");
        jButton10.setContentAreaFilled(false);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton11.setText("Dessert");
        jButton11.setContentAreaFilled(false);
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton12.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jButton12.setText("Promotion");
        jButton12.setContentAreaFilled(false);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel37, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel38, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton12, javax.swing.GroupLayout.DEFAULT_SIZE, 295, Short.MAX_VALUE)
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addComponent(jPanel37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel38, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel34.add(jPanel36, java.awt.BorderLayout.CENTER);

        jPanel33.add(jPanel34, java.awt.BorderLayout.LINE_END);

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Background/823486a158b1b4c54fa97524664f68aa.jpg"))); // NOI18N
        jPanel33.add(jLabel19, java.awt.BorderLayout.LINE_START);

        jPanel31.add(jPanel33, java.awt.BorderLayout.LINE_START);

        ManagePageSetting.setLayout(new java.awt.CardLayout());

        CreateMenu.setPreferredSize(new java.awt.Dimension(500, 300));
        CreateMenu.setLayout(new java.awt.BorderLayout());

        jPanel40.setBackground(new java.awt.Color(204, 204, 255));
        jPanel40.setPreferredSize(new java.awt.Dimension(473, 60));

        javax.swing.GroupLayout jPanel40Layout = new javax.swing.GroupLayout(jPanel40);
        jPanel40.setLayout(jPanel40Layout);
        jPanel40Layout.setHorizontalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 604, Short.MAX_VALUE)
        );
        jPanel40Layout.setVerticalGroup(
            jPanel40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        CreateMenu.add(jPanel40, java.awt.BorderLayout.PAGE_START);

        jPanel41.setBackground(new java.awt.Color(204, 204, 255));
        jPanel41.setForeground(new java.awt.Color(255, 204, 255));
        jPanel41.setPreferredSize(new java.awt.Dimension(60, 269));

        javax.swing.GroupLayout jPanel41Layout = new javax.swing.GroupLayout(jPanel41);
        jPanel41.setLayout(jPanel41Layout);
        jPanel41Layout.setHorizontalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel41Layout.setVerticalGroup(
            jPanel41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 463, Short.MAX_VALUE)
        );

        CreateMenu.add(jPanel41, java.awt.BorderLayout.LINE_START);

        jPanel42.setBackground(new java.awt.Color(204, 204, 255));
        jPanel42.setPreferredSize(new java.awt.Dimension(60, 269));

        javax.swing.GroupLayout jPanel42Layout = new javax.swing.GroupLayout(jPanel42);
        jPanel42.setLayout(jPanel42Layout);
        jPanel42Layout.setHorizontalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );
        jPanel42Layout.setVerticalGroup(
            jPanel42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 463, Short.MAX_VALUE)
        );

        CreateMenu.add(jPanel42, java.awt.BorderLayout.LINE_END);

        jPanel43.setBackground(new java.awt.Color(204, 204, 255));
        jPanel43.setPreferredSize(new java.awt.Dimension(473, 60));

        javax.swing.GroupLayout jPanel43Layout = new javax.swing.GroupLayout(jPanel43);
        jPanel43.setLayout(jPanel43Layout);
        jPanel43Layout.setHorizontalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 604, Short.MAX_VALUE)
        );
        jPanel43Layout.setVerticalGroup(
            jPanel43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        CreateMenu.add(jPanel43, java.awt.BorderLayout.PAGE_END);

        jPanel44.setBackground(new java.awt.Color(255, 255, 255));
        jPanel44.setPreferredSize(new java.awt.Dimension(500, 300));
        jPanel44.setLayout(new java.awt.BorderLayout());

        jPanel45.setBackground(new java.awt.Color(0, 153, 153));
        jPanel45.setForeground(new java.awt.Color(255, 255, 255));
        jPanel45.setMinimumSize(new java.awt.Dimension(100, 60));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel9.setText("Create Menu");
        jPanel45.add(jLabel9);

        jPanel44.add(jPanel45, java.awt.BorderLayout.PAGE_START);

        jPanel46.setBackground(new java.awt.Color(255, 255, 255));

        TextNamefood.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextNamefoodActionPerformed(evt);
            }
        });

        SelectTypefood.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        SelectTypefood.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectTypefoodActionPerformed(evt);
            }
        });

        Textnamephoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextnamephotoActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel10.setText("Name :");

        jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel11.setText("Type food :");

        jLabel12.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel12.setText("Photo :");

        jLabel13.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel13.setText("Price :");

        AddMenuButton.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        AddMenuButton.setText("ADD");
        AddMenuButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddMenuButtonActionPerformed(evt);
            }
        });

        TextID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextIDActionPerformed(evt);
            }
        });

        Addphotobutton.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        Addphotobutton.setText("Browse");
        Addphotobutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddphotobuttonActionPerformed(evt);
            }
        });

        TextPrice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextPriceActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel20.setText("ID :");

        javax.swing.GroupLayout jPanel46Layout = new javax.swing.GroupLayout(jPanel46);
        jPanel46.setLayout(jPanel46Layout);
        jPanel46Layout.setHorizontalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel46Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(33, 33, 33)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SelectTypefood, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(AddMenuButton, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextNamefood, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextID, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel46Layout.createSequentialGroup()
                        .addComponent(Textnamephoto, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Addphotobutton)))
                .addGap(146, 146, 146))
        );
        jPanel46Layout.setVerticalGroup(
            jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel46Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(TextNamefood, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(SelectTypefood, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextID, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addGap(18, 18, 18)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addGap(28, 28, 28)
                .addGroup(jPanel46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Textnamephoto, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Addphotobutton, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(42, 42, 42)
                .addComponent(AddMenuButton, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jPanel44.add(jPanel46, java.awt.BorderLayout.CENTER);

        CreateMenu.add(jPanel44, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(CreateMenu, "card2");

        DrinksMenu.setBackground(new java.awt.Color(255, 255, 255));
        DrinksMenu.setLayout(new java.awt.BorderLayout());

        jPanel47.setBackground(new java.awt.Color(0, 153, 153));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Drinks");
        jPanel47.add(jLabel14);

        DrinksMenu.add(jPanel47, java.awt.BorderLayout.PAGE_START);

        PageforDrinksMenu.setBackground(new java.awt.Color(255, 255, 255));
        PageforDrinksMenu.setLayout(new java.awt.GridLayout(0, 3));
        jScrollPane6.setViewportView(PageforDrinksMenu);

        DrinksMenu.add(jScrollPane6, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(DrinksMenu, "card3");

        MaincourseMenu.setLayout(new java.awt.BorderLayout());

        jPanel48.setBackground(new java.awt.Color(0, 153, 153));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Maincourse");
        jPanel48.add(jLabel15);

        MaincourseMenu.add(jPanel48, java.awt.BorderLayout.PAGE_START);

        jPanel49.setBackground(new java.awt.Color(255, 255, 255));
        jPanel49.setLayout(new java.awt.BorderLayout());

        PageforMaincourseMenu.setBackground(new java.awt.Color(255, 255, 255));
        PageforMaincourseMenu.setLayout(new java.awt.GridLayout(0, 3));
        jScrollPane7.setViewportView(PageforMaincourseMenu);

        jPanel49.add(jScrollPane7, java.awt.BorderLayout.CENTER);

        MaincourseMenu.add(jPanel49, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(MaincourseMenu, "card4");

        DessertMenu.setLayout(new java.awt.BorderLayout());

        jPanel50.setBackground(new java.awt.Color(0, 153, 153));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Dessert");
        jPanel50.add(jLabel16);

        DessertMenu.add(jPanel50, java.awt.BorderLayout.PAGE_START);

        jPanel51.setBackground(new java.awt.Color(255, 255, 255));
        jPanel51.setLayout(new java.awt.BorderLayout());

        PageforDessertMenu.setBackground(new java.awt.Color(255, 255, 255));
        PageforDessertMenu.setLayout(new java.awt.GridLayout(0, 3));
        jScrollPane8.setViewportView(PageforDessertMenu);

        jPanel51.add(jScrollPane8, java.awt.BorderLayout.CENTER);

        DessertMenu.add(jPanel51, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(DessertMenu, "card5");

        DrinksStock.setLayout(new java.awt.BorderLayout());

        jPanel52.setBackground(new java.awt.Color(0, 153, 153));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Drinks Stock");
        jPanel52.add(jLabel17);

        DrinksStock.add(jPanel52, java.awt.BorderLayout.PAGE_START);

        jPanel53.setBackground(new java.awt.Color(255, 255, 255));
        jPanel53.setLayout(new java.awt.BorderLayout());

        jScrollPane9.setHorizontalScrollBar(null);

        PageforDrinksStock.setBackground(new java.awt.Color(255, 255, 255));
        PageforDrinksStock.setLayout(new java.awt.GridLayout(0, 3));
        jScrollPane9.setViewportView(PageforDrinksStock);

        jPanel53.add(jScrollPane9, java.awt.BorderLayout.CENTER);

        DrinksStock.add(jPanel53, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(DrinksStock, "card6");

        MaincourseStock.setLayout(new java.awt.BorderLayout());

        jPanel54.setBackground(new java.awt.Color(0, 153, 153));

        jLabel21.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Maincourse Stock");
        jPanel54.add(jLabel21);

        MaincourseStock.add(jPanel54, java.awt.BorderLayout.PAGE_START);

        jPanel55.setBackground(new java.awt.Color(255, 255, 255));
        jPanel55.setLayout(new java.awt.BorderLayout());

        jScrollPane10.setBackground(new java.awt.Color(255, 255, 255));

        PageforMaincourseStock.setBackground(new java.awt.Color(255, 255, 255));
        PageforMaincourseStock.setLayout(new java.awt.GridLayout(0, 3));
        jScrollPane10.setViewportView(PageforMaincourseStock);

        jPanel55.add(jScrollPane10, java.awt.BorderLayout.CENTER);

        MaincourseStock.add(jPanel55, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(MaincourseStock, "card7");

        DessertStock.setLayout(new java.awt.BorderLayout());

        jPanel56.setBackground(new java.awt.Color(0, 153, 153));

        jLabel22.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Dessert Stock");
        jPanel56.add(jLabel22);

        DessertStock.add(jPanel56, java.awt.BorderLayout.PAGE_START);

        jPanel57.setBackground(new java.awt.Color(255, 255, 255));
        jPanel57.setLayout(new java.awt.BorderLayout());

        PageforDessertStock.setBackground(new java.awt.Color(255, 255, 255));
        PageforDessertStock.setLayout(new java.awt.GridLayout(0, 3));
        jScrollPane11.setViewportView(PageforDessertStock);

        jPanel57.add(jScrollPane11, java.awt.BorderLayout.CENTER);

        DessertStock.add(jPanel57, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(DessertStock, "card8");

        ManagePromotion.setLayout(new java.awt.BorderLayout());

        jPanel58.setBackground(new java.awt.Color(0, 102, 102));

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Manage Promotion");
        jPanel58.add(jLabel23);

        ManagePromotion.add(jPanel58, java.awt.BorderLayout.PAGE_START);

        jPanel59.setLayout(new java.awt.BorderLayout());

        jPanel60.setBackground(new java.awt.Color(0, 153, 153));
        jPanel60.setPreferredSize(new java.awt.Dimension(517, 60));
        jPanel60.setLayout(new java.awt.GridBagLayout());

        jButton13.setText("Drinks");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 20;
        gridBagConstraints.ipady = 10;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 100);
        jPanel60.add(jButton13, gridBagConstraints);

        jButton14.setText("Maincourse");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 20;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 100);
        jPanel60.add(jButton14, gridBagConstraints);

        jButton15.setText("Dessert");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 20;
        jPanel60.add(jButton15, gridBagConstraints);

        jPanel59.add(jPanel60, java.awt.BorderLayout.PAGE_START);

        jPanel61.setLayout(new java.awt.CardLayout());
        jPanel59.add(jPanel61, java.awt.BorderLayout.CENTER);

        ManagePromotion.add(jPanel59, java.awt.BorderLayout.CENTER);

        ManagePageSetting.add(ManagePromotion, "card10");

        jPanel31.add(ManagePageSetting, java.awt.BorderLayout.CENTER);

        Allpage.add(jPanel31, "card3");

        getContentPane().add(Allpage, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void QueueButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QueueButtonActionPerformed
       ManagePage.removeAll();
        ManagePage.add(QueuePage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_QueueButtonActionPerformed

    private void DrinksButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DrinksButtonActionPerformed
        ManagePage.removeAll();
        ManagePage.add(DrinksPage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_DrinksButtonActionPerformed

    private void MaincourseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MaincourseButtonActionPerformed
       ManagePage.removeAll();
        ManagePage.add(MaincoursePage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_MaincourseButtonActionPerformed

    private void DessertButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DessertButtonActionPerformed
       ManagePage.removeAll();
        ManagePage.add(DessertPage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_DessertButtonActionPerformed

    private void QueueButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_QueueButtonMouseClicked
        
    }//GEN-LAST:event_QueueButtonMouseClicked

    private void DrinksButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DrinksButtonMouseClicked
     
    }//GEN-LAST:event_DrinksButtonMouseClicked

    private void MaincourseButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MaincourseButtonMouseClicked
       
    }//GEN-LAST:event_MaincourseButtonMouseClicked

    private void DessertButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DessertButtonMouseClicked
      
    }//GEN-LAST:event_DessertButtonMouseClicked

    private void ExitGui1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitGui1ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_ExitGui1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       Allpage.removeAll();
        Allpage.add(jPanel31);
        Allpage.repaint();
        Allpage.revalidate();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void CartButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CartButtonActionPerformed
      ManagePage.removeAll();
        ManagePage.add(CartPage);
        ManagePage.repaint();
        ManagePage.revalidate();
    }//GEN-LAST:event_CartButtonActionPerformed

    private void CartButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CartButtonMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_CartButtonMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        new GuiBill().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:

        Allpage.removeAll();
        Allpage.add(jPanel30);
        Allpage.repaint();
        Allpage.revalidate();

    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(CreateMenu);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(DrinksMenu);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(MaincourseMenu);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(DessertMenu);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(DrinksStock);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(MaincourseStock);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(DessertStock);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        ManagePageSetting.removeAll();
        ManagePageSetting.add(ManagePromotion);
        ManagePageSetting.repaint();
        ManagePageSetting.revalidate();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void TextNamefoodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextNamefoodActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextNamefoodActionPerformed

    private void SelectTypefoodActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectTypefoodActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_SelectTypefoodActionPerformed

    private void TextnamephotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextnamephotoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextnamephotoActionPerformed

    private void AddMenuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddMenuButtonActionPerformed
        // TODO add your handling code here:
        String Selecttype=(String)SelectTypefood.getSelectedItem();
        double Setprice=Double.parseDouble(TextPrice.getText());
        try {
            shop.Createmenu(Selecttype,TextID.getText(),TextNamefood.getText(),Setprice,Textnamephoto.getText() );
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        Showguimenu.setData(TextID.getText(), TextNamefood.getText(), TextPrice.getText(),Selecttype);
        Showguimenu.setPhoto(Textnamephoto.getText() );
        if(Selecttype.equals("Drinks"))
        { PageforDrinksMenu.add(Showguimenu.getMenuPanel());
            PageforDrinksMenu.revalidate();
            PageforDrinksMenu.repaint(); }
        if(Selecttype.equals("Dessert"))
        { PageforDessertMenu.add(Showguimenu.getMenuPanel());
            PageforDessertMenu.revalidate();
            PageforDessertMenu.repaint(); }
        if(Selecttype.equals("Maincourse"))
        { PageforMaincourseMenu.add(Showguimenu.getMenuPanel());
            PageforMaincourseMenu.revalidate();
            PageforMaincourseMenu.repaint(); }

        SelectTypefood.setSelectedItem(null);
        TextID.setText("");TextPrice.setText("");
        TextNamefood.setText("");Textnamephoto.setText("");
    }//GEN-LAST:event_AddMenuButtonActionPerformed

    private void TextIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextIDActionPerformed

    private void AddphotobuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddphotobuttonActionPerformed
        // TODO add your handling code here:
        JFileChooser choose=new JFileChooser();
        int Checkchoose=choose.showOpenDialog(this);
        if(Checkchoose==JFileChooser.APPROVE_OPTION)
        {
            File file=choose.getSelectedFile();
            String path=file.getAbsolutePath().replace("\\","/");
                Textnamephoto.setText(path);

            }

    }//GEN-LAST:event_AddphotobuttonActionPerformed

    private void TextPriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextPriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextPriceActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new GuiRestaurant().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddMenuButton;
    private javax.swing.JButton Addphotobutton;
    private javax.swing.JPanel Allpage;
    private javax.swing.JButton CartButton;
    private javax.swing.JPanel CartPage;
    private javax.swing.JPanel CreateMenu;
    private java.awt.Button DessertButton;
    private javax.swing.JPanel DessertMenu;
    private javax.swing.JPanel DessertPage;
    private javax.swing.JPanel DessertStock;
    private java.awt.Button DrinksButton;
    private javax.swing.JPanel DrinksMenu;
    private javax.swing.JPanel DrinksPage;
    private javax.swing.JPanel DrinksStock;
    private javax.swing.JButton ExitGui1;
    private javax.swing.JPanel GoodsDessert;
    private javax.swing.JPanel GoodsDrinks;
    private javax.swing.JPanel GoodsMaincourse;
    private java.awt.Button MaincourseButton;
    private javax.swing.JPanel MaincourseMenu;
    private javax.swing.JPanel MaincoursePage;
    private javax.swing.JPanel MaincourseStock;
    private javax.swing.JPanel ManagePage;
    private javax.swing.JPanel ManagePageSetting;
    private javax.swing.JPanel ManagePromotion;
    private javax.swing.JPanel PageforDessertMenu;
    private javax.swing.JPanel PageforDessertStock;
    private javax.swing.JPanel PageforDrinksMenu;
    private javax.swing.JPanel PageforDrinksStock;
    private javax.swing.JPanel PageforMaincourseMenu;
    private javax.swing.JPanel PageforMaincourseStock;
    private java.awt.Button QueueButton;
    private javax.swing.JPanel QueuePage;
    private javax.swing.JComboBox<String> SelectTypefood;
    private javax.swing.JTextField TextID;
    private javax.swing.JTextField TextNamefood;
    private javax.swing.JTextField TextPrice;
    private javax.swing.JTextField Textnamephoto;
    private java.awt.Button button5;
    private java.awt.Button button6;
    private java.awt.Button button7;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel37;
    private javax.swing.JPanel jPanel38;
    private javax.swing.JPanel jPanel39;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel40;
    private javax.swing.JPanel jPanel41;
    private javax.swing.JPanel jPanel42;
    private javax.swing.JPanel jPanel43;
    private javax.swing.JPanel jPanel44;
    private javax.swing.JPanel jPanel45;
    private javax.swing.JPanel jPanel46;
    private javax.swing.JPanel jPanel47;
    private javax.swing.JPanel jPanel48;
    private javax.swing.JPanel jPanel49;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel50;
    private javax.swing.JPanel jPanel51;
    private javax.swing.JPanel jPanel52;
    private javax.swing.JPanel jPanel53;
    private javax.swing.JPanel jPanel54;
    private javax.swing.JPanel jPanel55;
    private javax.swing.JPanel jPanel56;
    private javax.swing.JPanel jPanel57;
    private javax.swing.JPanel jPanel58;
    private javax.swing.JPanel jPanel59;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel60;
    private javax.swing.JPanel jPanel61;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private java.awt.Label label1;
    private java.awt.Label label2;
    // End of variables declaration//GEN-END:variables
}
