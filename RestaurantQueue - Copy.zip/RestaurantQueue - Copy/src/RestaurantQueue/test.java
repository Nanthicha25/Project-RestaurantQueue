package RestaurantQueue;

import java.util.*;

import Menu.*;
import Stock.*;
import lib.*;
public class test {
    public static void main(String[] args) {
   //List<shopcart>buy=new ArrayList<>();
   shopcenter shop=new shopcenter();
    Drinks Drinks=new Drinks();
Dessert Dessert=new Dessert();
Maincourse Maincourse=new Maincourse();
//กำหนดหมวดหมู่อาหารกับประเภทอาหาร
shop.SetTypetoMenu("Drinks", Drinks);
shop.SetTypetoMenu("Maincourse", Maincourse);
shop.SetTypetoMenu("Dessert", Dessert);
//กำหนดประเภทอาหารในstock
DessertStock dessertStock=new DessertStock();
DrinksStock drinksStock=new DrinksStock();
MaincourseStock maincourseStock=new MaincourseStock();
shop.SetTypetoStock("Dessert",dessertStock);
shop.SetTypetoStock("Drinks",drinksStock);
shop.SetTypetoStock("Maincourse",maincourseStock);
//สร้างรายการอาหาร
try {
  shop.Createmenu("Drinks","P000","Cha",29,"Picabc");
   shop.Createmenu("Drinks","P001","Cola",29,"Picabc");
 shop.Createmenu("Drinks","P002","Water",29,"Picabc");
   shop.Createmenu("Drinks","P003","Juice",29,"Picabc");
   //สร้างรายการอาหารชื่อซ้ำ
   shop.Createmenu("Drinks","P004","Juice",29,"Picabc");
} catch (Exception e) {
  System.out.println(e.getMessage());
}
//อัพเดตรายการอาหาร
try {
  shop.Createmenu("Drinks","P003","Juice",100,"Picabc");
} catch (Exception e) {
  System.out.println(e.getMessage());
}
//ลบรายการอาหาร
try {
  shop.Deletemenu("P003");
} catch (Exception e) {
  System.out.println(e.getMessage());
}
//แสดงรายการอาหาร
try {
  shop.Showallmenu("Drinks");
} catch (Exception e) {
  System.out.println(e.getMessage());
}
//ล้างรายการอาหาร
try {
  shop.Clearmenu("Drinks");
} catch (Exception e) {
  System.out.println(e.getMessage());
}
//ลบรายการอาหารที่ไม่มีอยู่จริง
try {
  shop.Deletemenu("P003");
} catch (Exception e) {
  System.out.println(e.getMessage());
}
//ล้างรายการอาหารในหมวดหมู่ที่ไม่มีอาหาร
try {
  shop.Clearmenu("Dessert");
} catch (Exception e) {
  System.out.println(e.getMessage());
}
//แสดงรายการอาหารในหมวดหมู่ที่ไม่มีอาหาร
 try {
  shop.Showallmenu("Maincourse");
} catch (Exception e) {
  System.out.println(e.getMessage());
}
//ค้นหารายการอาหารที่มีอยู่ในเมนู
try { shop.Createmenu("Dessert","P000","Sweet",29,"Picabc");
   shop.Createmenu("Dessert","P001","Cake",29,"Picabc");
 shop.Createmenu("Dessert","P002","Chocolate",29,"Picabc");
   shop.Createmenu("Dessert","P003","Cereal",29,"Picabc");

   shop.findById("P000");
  
} catch (Exception e) {
  System.out.println(e.getMessage());
}
//ค้นหารายการอาหารที่ไม่มีอยู่ในเมนู
try {
 shop.findById("P099");
} catch (Exception e) {
  System.out.println(e.getMessage());
}



 //เพิ่มรายการอาหารในstock
 try {
  shop.Addstock("Dessert","P001","Cake");
  shop.Addstock("Dessert","P003","Cereal");
} catch (Exception e) {
  System.out.println(e.getMessage());
}
 //ลบรายการอาหารในstock
 try {
     
     shop.Updatepromotion("Dessert","P001","Cake",80.0);
 shop.Deletestock("Cereal");
 shop.Addcart("Sushi",2, "");
 shop.Updatepromotion("Maincourse", "P002", "Salmon", 999);
} catch (Exception e) {
  System.out.println(e.getMessage());
}
 //เพิ่มอาหารในstockซ้ำ
    }}

