/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lib;

/**
 *
 * @author nanth
 */
public class ManageCart {
    Datafilecart updatecart=new Datafilecart();
    public void Setquantityandcomment(String namefood, int quantity,String comment) throws InvalidOperationException {
        if (quantity< 0 ) {
            throw new InvalidOperationException("Invalid quantity");
        }
        
       updatecart.Changequantityandcomment(namefood,quantity,comment);
        
    }
    public void deletecart(String namefood,String comment)
    {
     updatecart.delete(namefood,comment);
    }
    public void clearcart()
    {
        updatecart.clear();
    }
    
}
