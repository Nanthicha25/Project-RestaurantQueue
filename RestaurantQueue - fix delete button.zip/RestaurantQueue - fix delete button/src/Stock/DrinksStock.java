package Stock;

import lib.Datafilestock;
import lib.InvalidOperationException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import lib.*;

public class DrinksStock implements stock {

    Datafilestock updatestock = new Datafilestock();

    @Override
    public void addfoodstock(String namefood, String id) throws InvalidOperationException {
        try {
            updatestock.writestock("Drinks", namefood, id);
        } catch (Exception ex) {
            Logger.getLogger(DrinksStock.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public void clearfoodstock() throws InvalidOperationException {

        updatestock.clear("DrinksStock");

    }

    @Override
    public List<String> getAllfoodsstock() {

        return updatestock.Showallstock("DrinksStock");
    }

    //@Override
    //public List<String> findstockByName(String namefood) throws goodsNotFoundException {
    //   return updatestock.findbyname(namefood,"DrinkStock");}
}
