package Menu;

import lib.food;
import lib.goodsNotFoundException;
import lib.InvalidOperationException;
import lib.Datafilemenu;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import lib.*;

public class Dessert implements menu {

    Datafilemenu updatemenu = new Datafilemenu();

    @Override
    public void addfood(food foods, String image) throws InvalidOperationException {
        try {
            updatemenu.write("Dessert", foods, image);
        } catch (Exception ex) {
            Logger.getLogger(Dessert.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void clearfood() throws goodsNotFoundException {

        updatemenu.clear("Dessert");
    }

    @Override
    public List<String> getAllfoods() {
        return updatemenu.Showallmenu("Dessert");

    }
}
