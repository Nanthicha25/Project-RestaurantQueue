package Stock;

import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import lib.*;

public class DessertStock implements stock {

    Datafilestock updatestock = new Datafilestock();

    @Override
    public void addfoodstock(String namefood, String id) throws InvalidOperationException {
        try {
            updatestock.writestock("Dessert", namefood, id);
        } catch (Exception ex) {
            Logger.getLogger(DessertStock.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void clearfoodstock() throws InvalidOperationException {
        updatestock.clear("DessertStock");

    }

    @Override
    public List<String> getAllfoodsstock() {
        return updatestock.Showallstock("DessertStock");
    }

//public List<String> findstockByName(String namefood) throws goodsNotFoundException {
    //return updatestock.findbyname(namefood,"DessertStock");}
}
