package lib;

public class goodsNotFoundException extends Exception {

    public goodsNotFoundException(String message) {
        super(message);
    }
}
